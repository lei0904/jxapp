define('jxapp/1.0.0/exercise/index.js', function(require, exports, module){var Ces = require('ces');
var Cui =require('cui');
var Collect = require('examCollect');

module.exports = {
    template: "<div class=\"exercise\">\n    <cui-navbar class=\"page-part\" v-model=\"selected\" >\n        <cui-tab-item id=\"1\">科目一</cui-tab-item>\n        <cui-tab-item id=\"2\">科目二</cui-tab-item>\n        <cui-tab-item id=\"3\">科目三</cui-tab-item>\n        <cui-tab-item id=\"4\">科目四</cui-tab-item>\n    </cui-navbar>\n    <div class=\"exercise-content\">\n    <cui-tab-container v-model=\"selected\">\n        <cui-tab-container-item id=\"1\">\n            <div >\n                <div class=\"practice\">答题练习</div>\n                <div class=\"exercise-model\">\n                    <div class=\"exercise-title\">\n                        <div class=\"exercise-item\" @click=\"toPractice(1)\">\n                            <i class=\"sxlx\"></i>\n                            <span class=\"titles \">顺序练习</span>\n                        </div>\n                        <div class=\"exercise-item\" @click=\"toPractice(2)\">\n                            <i class=\"zxlx\"></i>\n                            <span class=\"titles\">专项练习</span>\n                        </div>\n                    </div>\n                    <div class=\"exercise-title\">\n                        <div class=\"exercise-item\"  @click=\"toPractice(3)\">\n                            <i class=\"sjlx\"></i>\n                            <span class=\"titles\">随机练习</span>\n                        </div>\n                        <div class=\"exercise-item\"  @click=\"toPractice(4)\">\n                            <i class=\"mnlx\"></i>\n                            <span class=\"titles\">模拟考试</span>\n                        </div>\n                    </div>\n                </div>\n            </div>\n            <div >\n                <div class=\"practice\">我的练习</div>\n                <div class=\"exercise-history\">\n                    <div class=\"exercise-title\">\n                        <div class=\"exercise-item\" @click=\"toPractice(5)\">\n                            <i class=\"wdsc\"></i>\n                            <span>我的收藏</span>\n                        </div>\n                        <div class=\"exercise-item\" @click=\"toPractice(6)\">\n                            <i class=\"wdct\"></i>\n                            <span>我的错题</span>\n                        </div>\n                    </div>\n                    <div class=\"exercise-title\">\n                        <div class=\"exercise-item\" @click=\"toPractice(7)\">\n                            <i class=\"dtjq\"></i>\n                            <span>答题技巧</span>\n                        </div>\n                        <div class=\"exercise-item\"  @click=\"toPractice(8)\">\n                            <i class=\"ksgz\"></i>\n                            <span>考试规则</span>\n                        </div>\n                    </div>\n                </div>\n            </div>\n        </cui-tab-container-item>\n\n        <cui-tab-container-item id=\"2\">\n            敬请期待\n        </cui-tab-container-item>\n\n        <cui-tab-container-item id=\"3\">\n            敬请期待\n        </cui-tab-container-item>\n\n        <cui-tab-container-item id=\"4\">\n            <div >\n                <div class=\"practice\">答题练习</div>\n                <div class=\"exercise-model\">\n                    <div class=\"exercise-title\">\n                        <div class=\"exercise-item\" @click=\"toPractice(1)\">\n                            <i class=\"sxlx\"></i>\n                            <span class=\"titles \">顺序练习</span>\n                        </div>\n                        <div class=\"exercise-item\" @click=\"toPractice(2)\">\n                            <i class=\"zxlx\"></i>\n                            <span class=\"titles\">专项练习</span>\n                        </div>\n                    </div>\n                    <div class=\"exercise-title\">\n                        <div class=\"exercise-item\"  @click=\"toPractice(3)\">\n                            <i class=\"sjlx\"></i>\n                            <span class=\"titles\">随机练习</span>\n                        </div>\n                        <div class=\"exercise-item\"  @click=\"toPractice(4)\">\n                            <i class=\"mnlx\"></i>\n                            <span class=\"titles\">模拟考试</span>\n                        </div>\n                    </div>\n                </div>\n            </div>\n            <div >\n                <div class=\"practice\">我的练习</div>\n                <div class=\"exercise-history\">\n                    <div class=\"exercise-title\">\n                        <div class=\"exercise-item\" @click=\"toPractice(5)\">\n                            <i class=\"wdsc\"></i>\n                            <span>我的收藏</span>\n                        </div>\n                        <div class=\"exercise-item\" @click=\"toPractice(6)\">\n                            <i class=\"wdct\"></i>\n                            <span>我的错题</span>\n                        </div>\n                    </div>\n                    <div class=\"exercise-title\">\n                        <div class=\"exercise-item\" @click=\"toPractice(7)\">\n                            <i class=\"dtjq\"></i>\n                            <span>答题技巧</span>\n                        </div>\n                        <div class=\"exercise-item\" @click=\"toPractice(8)\">\n                            <i class=\"ksgz\"></i>\n                            <span>考试规则</span>\n                        </div>\n                    </div>\n                </div>\n            </div>\n        </cui-tab-container-item>\n    </cui-tab-container>\n    </div>\n</div>",
    data: function () {
        return {
            selected: '1'
        }
    },
    methods: {
        toPractice:function (obj) {
            var params = JSON.stringify({'subject':this.selected,'type':obj,'start':true,questions:0});
            sessionStorage.setItem("topic",params);
            console.log('toPractice', sessionStorage.getItem("topic"));
           if( obj == 2){
                this.$router.push({'path':'/examsDir'})
            }else if(obj == 1 || obj == 3 || obj == 4){
                this.$router.push({path:'/exams'})
            }
            else if(obj ==5 || obj == 6){
               var localParams = JSON.parse(params);
               if( Collect.getQLength(localParams) >0){
                   this.$router.push({path:'/examsLocal',query:localParams})
               }else{
                   var message = "";
                    if(obj ==5){
                        message = "没有收藏题目"
                    }else{
                        message = "没有收集到错题"
                    }
                   Cui.Toast({
                       message: message,
                       position: 'bottom'
                   });
               }
           }
           else if(obj == 7){
                console.log("答题技巧");
                this.$router.push({'path':'/examRules',query:obj});
           }else {
               console.log("考试规则");
               this.$router.push({'path':'/examRules',query:obj});
           }

        }
    }
};

});