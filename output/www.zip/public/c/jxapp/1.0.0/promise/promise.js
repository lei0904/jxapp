define('jxapp/1.0.0/promise/promise.js', function(require, exports, module){var Ces = require('ces');
var Cui = require('cui');
var Api = require('api');

module.exports = {
    template: "<div>\n    <div class=\"static_module\">\n        <div class=\"static_module_header\">\n            收费透明\n        </div>\n        <div class=\"static_module_content\">\n            <div class=\"static_module_content_item\">\n                 费用包括理论培训费、训练费、考试预约费、制证工本费。\n            </div>\n            <div class=\"static_module_content_item\">\n                费用不包括补考费。\n            </div>\n        </div>\n    </div>\n    <div class=\"static_module\">\n        <div class=\"static_module_header\">\n            预约练车\n        </div>\n        <div class=\"static_module_content\">\n            <div class=\"static_module_content_item\">\n                学员线上app轻松预约，无需排队练车！\n            </div>\n            <div class=\"static_module_content_item\">\n                训练时间由你定，更自由！\n            </div>\n        </div>\n    </div>\n    <div class=\"static_module\">\n        <div class=\"static_module_header\">\n            快速拿证\n        </div>\n        <div class=\"static_module_content\">\n            <div class=\"static_module_content_item\">\n                拒绝拖、慢、等，最快速度拿证！\n            </div>\n        </div>\n    </div>\n    <div class=\"static_module\">\n        <div class=\"static_module_header\">\n            限时维权\n        </div>\n        <div class=\"static_module_content\">\n            <div class=\"static_module_content_item\">\n                积极响应学员维权问题。\n            </div>\n            <div class=\"static_module_content_item\">\n                绝不以任何借口推脱。\n            </div>\n            <div class=\"static_module_content_item\">\n                实事求是的解决问题。\n            </div>\n        </div>\n    </div>\n\n</div>",
    data: function () {
        return {

        }
    },
    methods: {

    }
};

});