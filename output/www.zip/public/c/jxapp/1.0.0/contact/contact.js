define('jxapp/1.0.0/contact/contact.js', function(require, exports, module){var Ces = require('ces');
var Cui = require('cui');
var Api = require('api');

module.exports = {
    template: "<div>\n    <cui-cell title=\"固话\" value=\"0551-66018610\"></cui-cell>\n    <cui-cell title=\"微信\" value=\"18712371888\"></cui-cell>\n    <cui-cell title=\"QQ\" value=\"663688576 3189218168\"></cui-cell>\n</div>",
    data: function () {
        return {

        }
    },
    methods: {

    }
};

});