define('jxapp/1.0.0/account/account.js', function(require, exports, module){var Ces = require('ces');
var Cui = require('cui');
var Api = require('api');

module.exports = {
    template: "<div>\n    <div class=\"highLightTitle\">\n        惠学车应用正式上线啦！\n    </div>\n    <div class=\"subExtDate\">\n        2017-8-15\n    </div>\n    <div class=\"static_module\">\n        <div class=\"static_module_header\">\n            在线练习\n        </div>\n        <div class=\"static_module_content\">\n            <div class=\"static_module_content_item\">\n                科目一、科目四在线随意练！\n            </div>\n            <div class=\"static_module_content_item\">\n                科目一、科目四在线随意考！\n            </div>\n            <div class=\"static_module_content_item\">\n                科目二、科目三在线视频随意看！\n            </div>\n        </div>\n    </div>\n    <div class=\"static_module\">\n        <div class=\"static_module_header\">\n            在线预约\n        </div>\n        <div class=\"static_module_content\">\n            <div class=\"static_module_content_item\">\n                科目二训练在线约！在也不用跟别人抢车了！\n            </div>\n            <div class=\"static_module_content_item\">\n                vip还能约晚上和周日的班次！\n            </div>\n        </div>\n    </div>\n    <div class=\"static_module\">\n        <div class=\"static_module_header\">\n            有偿推广\n        </div>\n        <div class=\"static_module_content\">\n            <div class=\"static_module_content_item\">\n                学个车还赚钱了！\n                我要约100个小伙伴！\n            </div>\n        </div>\n    </div>\n\n</div>",
    data: function () {
        return {

        }
    },
    methods: {

    }
};

});