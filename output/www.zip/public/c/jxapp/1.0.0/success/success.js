define('jxapp/1.0.0/success/success.js', function(require, exports, module){var Ces = require('ces');
var Cui = require('cui');
var Api = require('api');

module.exports = {
    template: "<div class=\"success\">\n     <div class=\"score\">得分:<span>{{score}}</span></div>\n     <div class=\"dis\"> 结果: <span v-bind:class=\"{ 'green': pass, 'red': !pass }\">{{dis}}</span></div>\n</div>",
    data: function () {
        return {
            score:0,
            dis:'',
            pass:false
        }
    },
    methods:{
    },
    activated:function(){
        console.log("=======",this.$route);
        this.score=this.$route.query.score;

        if( parseInt(this.score) >= 60){
            this.dis = "合格";
            this.pass = true
        }else{
            this.dis = "不合格";
            this.pass = false
        }
    }
};

});