define('jxapp/1.0.0/shuttleList/index.js', function(require, exports, module){module.exports = {
    template: "<div>\n    <div class=\"part\">\n        <!--<div class=\"part_header\">我的接送</div>-->\n        <div v-show=\"!empty\" class=\"part_content\">\n            <div class=\"list_item clearfix\" v-for=\"item in list\">\n                <div> {{item.shuttle_date}} {{item.shuttle_time}}\n                    <span class=\"s_status\" v-if=\"item.audit_status == 1\">待审核</span>\n                    <span class=\"s_status\" v-if=\"item.audit_status == 2\">审核通过</span>\n                    <span class=\"s_status\" v-if=\"item.audit_status == 3\">审核驳回</span>\n                </div>\n                <div> {{item.shuttle_address}} </div>\n            </div>\n        </div>\n        <div v-show=\"empty\" class=\"empty\">\n            暂无预约\n        </div>\n    </div>\n</div>",
    data: function () {
        return {
            list: [],
            empty:false
        }
    },
    methods: {

    },
    activated: function () {
        var _this = this;
        _this.$api.get('api/biz/shuttle/mine', {})
            .then(function (rets) {
                _this.$api.process(rets, function (rets) {
                    var data = rets.data;
                    if (data) {
                        _this.list = data;
                        if(data.length == 0){
                            _this.empty = true ;
                        }
                    } else {
                        _this.list = [];
                        _this.empty = true ;
                    }
                });
            })
    }
};

});