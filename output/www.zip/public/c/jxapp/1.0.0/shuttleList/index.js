define('jxapp/1.0.0/shuttleList/index.js', function(require, exports, module){module.exports = {
    template: "<div>\r\n    <div class=\"part\">\r\n        <!--<div class=\"part_header\">我的接送</div>-->\r\n        <div class=\"part_content\">\r\n            <div class=\"list_item clearfix\" v-for=\"item in list\">\r\n                <div> {{item.shuttle_date}} {{item.shuttle_time}} </div>\r\n                <div> {{item.shuttle_address}} </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>",
    data: function () {
        return {
            list: []
        }
    },
    methods: {

    },
    activated: function () {
        var _this = this;
        _this.$api.get('api/biz/shuttle/mine', {})
            .then(function (rets) {
                _this.$api.process(rets, function (rets) {
                    var data = rets.data;
                    if (data) {
                        _this.list = data;
                    } else {
                        _this.list = [];
                    }
                });
            })
    }
};

});