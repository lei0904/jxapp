define('jxapp/1.0.0/register/index.js', function(require, exports, module){var Ces = require('ces');
var Cui = require('cui');

module.exports = {
    template: "<div  class=\"register\">\n    <div class=\"register_head\">\n        <img src=\"/jxapp/1.0.0/lib/images/logo-main.png\">\n    </div>\n    <div class=\"register_content\">\n\n        <section class=\"MessageLogin-FsPlX\">\n            <input type=\"tel\" v-validate=\"'required|mobile'\" name=\"手机号码\" maxlength=\"11\" v-model=\"mobile\" placeholder=\"手机号码\">\n            <button class=\"CountButton\" @click=\"getVerifyCode\">\n                获取验证码\n            </button>\n        </section>\n        <cui-field  label=\"\" v-validate=\"'required'\" data-vv-name=\"验证码\" v-model=\"code\" placeholder=\"请输入验证码\" ></cui-field>\n        <cui-field  label=\"\" v-validate=\"'required'\" data-vv-name=\"密码\" name=\"密码\" v-model=\"password\" placeholder=\"请设定密码\" type=\"password\"></cui-field>\n        <cui-field  label=\"\" v-validate=\"'required|confirmed:密码'\" data-vv-name=\"确认密码\" v-model=\"password2\" placeholder=\"请确认密码\" type=\"password\"></cui-field>\n        <cui-field  label=\"\" v-model=\"invite_or_mobile\" placeholder=\"请输入邀请码\" ></cui-field>\n    </div>\n    <div class=\"register_end\">\n        <cui-button class=\"current-button\" size=\"large\" @click.native=\"submit\">完成</cui-button>\n    </div>\n</div>",
    data: function () {
        return {
            mobile: '',
            code: '',
            password: '',
            password2: '',
            invite_or_mobile: '',
            msg_id: ''
        }
    },
    methods: {
        getVerifyCode: function (e) {
            if (e.target.getAttribute("disable")) {
                return;
            }
            if (!this.mobile) {
                Cui.Toast({
                    message: '请输入注册手机号',
                    position: 'bottom'
                });
                return;
            }

            var timeout = 10;
            e.target.setAttribute("disable", "disable");
            e.target.innerHTML = timeout  + 's重新获取';
            var i = setInterval(function () {
                if (timeout === 1) {
                    clearInterval(i);
                    timeout = 10;
                    e.target.innerHTML = '重新获取';
                    e.target.removeAttribute("disable");
                } else {
                    timeout = timeout - 1;
                    e.target.innerHTML = timeout  + 's重新获取';
                }
            }, 1000);
            var _this = this;
            _this.$api.get('api/register/sms/' + this.mobile, {}, false).then(function (rets) {
                _this.$api.process(rets, function (rets) {
                    _this.msg_id = rets.data;
                }, function (rets) {
                    Cui.Toast({
                        message: rets.message,
                        position: 'bottom'
                    });
                });
            });
        },
        submit: function () {
            var _this = this;
            if (!this.msg_id) {
                Cui.Toast({
                    message: '请获取注册验证码',
                    position: 'bottom'
                });
                return;
            }
            _this.$validator.validateAll().then(function(result) {
                if (!result) {
                    _this.$validator.renderError();
                    return;
                }

                Ces.JSBridge.callHandler('jpush', [], function (rets) {
                    if (rets && rets.status === 1 && rets.data) {
                        var pushId = rets.data;
                        _this.$data.pushId = pushId;

                        _this.$api.post('api/register', JSON.parse(JSON.stringify(_this.$data)), false).then(function (rets) {
                            _this.$api.process(rets, function (rets) {
                                _this.$api.LoginData.set(rets.data, function () {
                                    _this.$router.push({ path: '/index' });
                                }, function () {
                                    Cui.MessageBox.alert('系统异常，注册失败');
                                });
                            });
                        });
                    } else {
                        Cui.MessageBox.alert('系统异常，注册失败');
                    }
                });
            });
        }
    }
};

});