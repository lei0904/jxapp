define('jxapp/1.0.0/examStorage/examStorage.js', function(require, exports, module){/**
 * Created by lei on 2017/7/26.
 */
/**
 * Created by lei on 2017/7/25.
 */
var Ces = require('ces');
var Cui = require('cui');
var sessionStorage = {
     sessionSetQ:function (){

     },
     sessionGetQ:function (){

    },
     sessionRemoveQ:function () {

     },
     storageLength:function(){

     }
}
module.exports = sessionStorage ;

});