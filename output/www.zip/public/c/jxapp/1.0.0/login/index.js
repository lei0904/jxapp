define('jxapp/1.0.0/login/index.js', function(require, exports, module){var Ces = require('ces');
var Cui = require('cui');

module.exports = {
    template: "<div class=\"login_bg\">\n    <div class=\"login-form is-12\">\n        <div class=\"login_con clearfix\">\n            <i class=\"user_icon icon\"></i>\n            <input\n                    v-validate=\"'required|mobile'\"\n                    v-model=\"user\"\n                    class=\"login_input login-user\"\n                    type=\"text\"\n                    name=\"手机号码\"\n                    placeholder=\"请输入手机号码\">\n        </div>\n        <div class=\"login_con clear\">\n            <i class=\"password_icon icon\"></i>\n            <input class=\"login_input login-password\"\n                   v-validate=\"'required'\"\n                   v-model=\"password\"\n                   type=\"password\"\n                   name=\"登录密码\"\n                   placeholder=\"请输入登录密码\">\n        </div>\n\n        <cui-button @click.native=\"doLogin\"\n                    class=\"login-form-button\"\n                    size=\"large\">登录</cui-button>\n        <div class=\"bottom_con clear\">\n            <span class=\"left\"><router-link  to=\"/register\"><span>注册</span></router-link></span>\n            <span class=\"right\"><router-link  to=\"/forgotPassword\"><span>忘记密码</span></router-link></span>\n        </div>\n    </div>\n\n\n    <!--\n<div class=\"column is-12\">\n    <label class=\"label\" for=\"email\">Email</label>\n    <p :class=\"{ 'control': true }\">\n        <input v-validate=\"'required|email'\" :class=\"{'input': true, 'is-danger': errors.has('email') }\" name=\"email\" type=\"text\" placeholder=\"Email\">\n        <span v-show=\"errors.has('email')\" class=\"help is-danger\">{{ errors.first('email') }}</span>\n    </p>\n</div>\n-->\n</div>\n\n",
    data: function () {
        return {
            full: false,
            animate: "left-fade",
            user: '13365698927',
            password: '123456'
        }
    },
    methods: {
        doLogin: function () {
            var _this = this;
            _this.$validator.validateAll().then(function(result) {
                if (!result) {
                    _this.$validator.renderError();
                    return;
                }
                _this.$api.post('api/login', {
                    mobile: _this.user,
                    password: _this.password
                }).then(function (rets) {
                    if (rets.status !== 'OK') {
                        Cui.Toast({
                            message: rets.message,
                            position: 'bottom'
                        });
                    } else {
                        _this.$api.LoginData.set(rets.data, function () {
                            _this.$router.push({ path: '/index' });
                        }, function () {
                            Cui.MessageBox.alert('系统异常，登录失败');
                        });
                    }
                });
            });
        },
        register: function () {
            this.$router.push({ path: '/register' });
        },
        openAttr: function () {
            this.$refs.picker2.open();
        },
        attrChange: function (value) {
            this.userAttr = value.name;
            this.type = value.code;
        }
    }
};


});