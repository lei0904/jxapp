define('jxapp/1.0.0/bespeakList/index.js', function(require, exports, module){var moment = require('jxapp/1.0.0/moment/moment.js');

module.exports = {
    template: "<div id=\"bespeakList\">\n    <div class=\"part\">\n        <div class=\"part_header\">当前进度</div>\n        <div class=\"part_content\">\n            <p>{{trainee|traineeStatus}}</p>\n        </div>\n    </div>\n\n    <div class=\"part\">\n        <div class=\"part_header\">我的预约</div>\n        <div class=\"part_content\">\n            <div class=\"list_item clearfix\" v-for=\"item in pending\">\n                <span class=\"list_item_left\"> {{item.t_date}} {{item.t_start_time|formatTime}}-{{item.t_end_time|formatTime}} </span>\n                <span class=\"list_item_center\"> {{item.c_name}}({{item.c_plate}}) </span>\n                <span class=\"list_item_right\"> 待确认 </span>\n            </div>\n            <div v-show=\"emptyNow\" class=\"emptyNow\">\n                暂无预约\n            </div>\n        </div>\n    </div>\n\n    <div class=\"part\">\n        <div class=\"part_header\">历史预约</div>\n        <div class=\"part_content\">\n            <div class=\"list_item clearfix\" v-for=\"item in success\">\n                <span class=\"list_item_left\"> {{item.t_date}} {{item.t_start_time|formatTime}}-{{item.t_end_time|formatTime}} </span>\n                <span class=\"list_item_center\"> {{item.c_name}}({{item.c_plate}}) </span>\n                <span class=\"list_item_right\"> {{item|time}} </span>\n            </div>\n            <div v-show=\"emptyPast\" class=\"emptyPast\">\n                暂无预约\n            </div>\n        </div>\n    </div>\n</div>",
    data: function () {
        return {
            trainee: {},
            success: [],
            pending: [],
            emptyNow:false,
            emptyPast:false
        }
    },
    methods: {

    },
    filters: {
        formatTime: function (d) {
            if (d) {
                var arr = (d + "").split(':');
                return arr[0] + ":" + arr[1];
            }
            return '';
        },
        time: function (item) {
            if (item) {
                if (item['b_status'] === 3) {
                    return '已驳回'
                }
                return item['b_period'] + '时';
                /*var d = item['t_date'];
                var s = item['t_start_time'];
                var e = item['t_end_time'];

                var start_day = moment(d + " " + s);
                var end_day = moment(d + " " + e);

                var b = end_day.diff(start_day);
                return (b / 3600000) + '时';*/
                /*var start = new Date(d + " " + s);
                var end = new Date(d + " " + e);

                var b = end.getTime() - start.getTime();

                return (b / 3600000) + '时';*/
            }
            return '0时';
        },
        traineeStatus: function (trainee) {
            var t_status = trainee['t_status'];
            return {
                0:'未缴费',
                1:'科目一',
                2:'科目二',
                3:'科目三',
                4:'科目四'
            }[t_status];
        }
    },
    activated: function () {
        var _this = this;
        _this.trainee = {};
        _this.success = [];
        _this.pending = [];
        _this.$api.get('api/biz/bespeak/mine', {})
            .then(function (rets) {
                _this.$api.process(rets, function (rets) {
                    var data = rets.data;
                    if (data) {
                        _this.trainee = data.trainee;
                        _this.success = data.success;
                        if (data.success.length == 0){
                            _this.emptyPast = true;
                        }
                        _this.pending = data.pending;
                        if (data.pending.length == 0){
                            _this.emptyNow = true;
                        }
                        console.log(_this.pending);
                    } else {
                        _this.trainee = {};
                        _this.success = [];
                        _this.pending = [];
                        _this.emptyPast = true;
                        _this.emptyNow = true;
                    }
                });
            })
    }
};

});