define('jxapp/1.0.0/bespeakList/index.js', function(require, exports, module){module.exports = {
    template: "<div>\r\n    <div class=\"part\">\r\n        <div class=\"part_header\">套餐名称</div>\r\n        <div class=\"part_content\">\r\n            <p>{{trainee|traineeStatus}}</p>\r\n        </div>\r\n    </div>\r\n\r\n    <div class=\"part\">\r\n        <div class=\"part_header\">我的预约</div>\r\n        <div class=\"part_content\">\r\n            <div class=\"list_item clearfix\" v-for=\"item in pending\">\r\n                <span class=\"list_item_left\"> {{item.t_date}} {{item.t_start_time|formatTime}}-{{item.t_end_time|formatTime}} </span>\r\n                <span class=\"list_item_center\"> {{item.c_name}}({{item.c_plate}}) </span>\r\n                <span class=\"list_item_right\"> 待确认 </span>\r\n            </div>\r\n        </div>\r\n    </div>\r\n\r\n    <div class=\"part\">\r\n        <div class=\"part_header\">历史预约</div>\r\n        <div class=\"part_content\">\r\n            <div class=\"list_item clearfix\" v-for=\"item in success\">\r\n                <span class=\"list_item_left\"> {{item.t_date}} {{item.t_start_time|formatTime}}-{{item.t_end_time|formatTime}} </span>\r\n                <span class=\"list_item_center\"> {{item.c_name}}({{item.c_plate}}) </span>\r\n                <span class=\"list_item_right\"> {{item|time}} </span>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>",
    data: function () {
        return {
            trainee: {},
            success: [],
            pending: []
        }
    },
    methods: {

    },
    filters: {
        formatTime: function (d) {
            if (d) {
                var arr = (d + "").split(':');
                return arr[0] + ":" + arr[1];
            }
            return '';
        },
        time: function (item) {
            if (item) {
                var d = item['t_date'];
                var s = item['t_start_time'];
                var e = item['t_end_time'];

                var start = new Date(d + " " + s);
                var end = new Date(d + " " + e);

                var b = end.getTime() - start.getTime();

                return (b / 3600000) + '时';
            }
            return '0时';
        },
        traineeStatus: function (trainee) {
            var t_status = trainee['t_status'];
            return {
                0:'未缴费',
                1:'科目一',
                2:'科目二',
                3:'科目三',
                4:'科目四'
            }[t_status];
        }
    },
    activated: function () {
        var _this = this;
        _this.$api.get('api/biz/bespeak/mine', {})
            .then(function (rets) {
                _this.$api.process(rets, function (rets) {
                    var data = rets.data;
                    if (data) {
                        _this.trainee = data.trainee;
                        _this.success = data.success;
                        _this.pending = data.pending;
                        console.log(_this.pending);
                    } else {
                        _this.trainee = {};
                        _this.success = {};
                        _this.pending = {};
                    }
                });
            })
    }
};

});