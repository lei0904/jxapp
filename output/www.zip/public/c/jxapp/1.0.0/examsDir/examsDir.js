define('jxapp/1.0.0/examsDir/examsDir.js', function(require, exports, module){/**
 * Created by lei on 2017/7/17.
 */
var Ces = require('ces');
var Cui = require('cui');
var Api = require('api');

module.exports = {
    template: "<div class=\"examsDir\">\n    <div class=\"exams-title\">专项训练</div>\n    <div v-for='(item,index) in list' @click=\"toExams(item)\">\n        <div class=\"special-contnent\">\n            <div class=\"special-title\">\n                <div class=\"special-item\">\n                    <span class=\"special-title-seq\">{{index+1}}</span>\n                    <span class=\"special-title-item\">{{item.name}}</span>\n                </div>\n            </div>\n            <div class=\"special-length\">{{item.length}}</div>\n        </div>\n    </div>\n</div>",
    data: function () {
        return {
             list:[]
        }
    },
    methods: {
        toExams:function(item){
            var topic =JSON.parse(sessionStorage.getItem('topic'));
                topic.questions=1;
                topic.start=true;
                topic.chapterDesc = item.name;
                topic.totalAnswer = item.length;
            sessionStorage.setItem('topic',JSON.stringify(topic));

            this.$router.push({'path':'/exams'})
        }
    },
    activated: function(){
        var params =JSON.parse(sessionStorage.getItem('topic'));

        var nativeRes = [parseInt(params.subject),{'type':params.type,'question':0,'chapterDesc':params.chapterDesc,'start':params.start}];

        console.log("nativeRes====",nativeRes);

        var _ts =this;
        Ces.Plugins.nativeApi.questions(nativeRes,function(rets){
            console.log(" 第一次进入==",rets);
            _ts.list=rets.data
        })
    }
};

});