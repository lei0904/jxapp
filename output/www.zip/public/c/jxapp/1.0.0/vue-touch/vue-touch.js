define('jxapp/1.0.0/vue-touch/vue-touch.js', function(require, exports, module){(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(require('jxapp/1.0.0/vue-touch/hammer.js')) :
        typeof define === 'function' && define.amd ? define(['hammer.js'], factory) :
            (factory(global.Hammer));
}(this, (function (Hammer) {
    'use strict';

    Hammer = 'default' in Hammer ? Hammer['default'] : Hammer;

    function assign(target) {
        var sources = [], len = arguments.length - 1;
        while (len-- > 0) sources[len] = arguments[len + 1];
        for (var i = 0; i < sources.length; i++) {
            var source = sources[i];
            var keys = Object.keys(source);
            for (var i$1 = 0; i$1 < keys.length; i$1++) {
                var key = keys[i$1];
                target[key] = source[key];
            }
        }
        return target
    }

    function createProp() {
        return {
            type: Object,
            default: function () {
                return {}
            }
        }
    }

    function capitalize(str) {
        return str.charAt(0).toUpperCase() + str.slice(1)
    }

    var directions = ['up', 'down', 'left', 'right', 'horizontal', 'vertical', 'all'];

    function guardDirections(options) {
        var dir = options.direction;
        if (typeof dir === 'string') {
            var hammerDirection = 'DIRECTION_' + dir.toUpperCase();
            if (directions.indexOf(dir) > -1 && Hammer.hasOwnProperty(hammerDirection)) {
                options.direction = Hammer[hammerDirection];
            } else {
                console.warn('[vue-touch] invalid direction: ' + dir);
            }
        }
        return options
    }

    var config = {};
    var customEvents = {};
    var gestures = [
        'pan', 'panstart', 'panmove', 'panend', 'pancancel', 'panleft', 'panright', 'panup', 'pandown',
        'pinch', 'pinchstart', 'pinchmove', 'pinchend', 'pinchcancel', 'pinchin', 'pinchout',
        'press', 'pressup',
        'rotate', 'rotatestart', 'rotatemove', 'rotateend', 'rotatecancel',
        'swipe', 'swipeleft', 'swiperight', 'swipeup', 'swipedown',
        'tap'
    ];
    var gestureMap = {
        pan: 'pan',
        panstart: 'pan',
        panmove: 'pan',
        panend: 'pan',
        pancancel: 'pan',
        panleft: 'pan',
        panright: 'pan',
        panup: 'pan',
        pandown: 'pan',
        pinch: 'pinch',
        pinchstart: 'pinch',
        pinchmove: 'pinch',
        pinchend: 'pinch',
        pinchcancel: 'pinch',
        pinchin: 'pinch',
        pinchout: 'pinch',
        press: 'press',
        pressup: 'press',
        rotate: 'rotate',
        rotatestart: 'rotate',
        rotatemove: 'rotate',
        rotateend: 'rotate',
        rotatecancel: 'rotate',
        swipe: 'swipe',
        swipeleft: 'swipe',
        swiperight: 'swipe',
        swipeup: 'swipe',
        swipedown: 'swipe',
        tap: 'tap'
    };

    var Component = {
        props: {
            options: createProp(),
            tapOptions: createProp(),
            panOptions: createProp(),
            pinchOptions: createProp(),
            pressOptions: createProp(),
            rotateOptions: createProp(),
            swipeOptions: createProp(),
            tag: {type: String, default: 'div'},
            enabled: {
                default: true,
                type: [Boolean, Object],
            }
        },
        mounted: function mounted() {
            if (!this.$isServer) {
                this.hammer = new Hammer.Manager(this.$el, this.options);
                this.recognizers = {};
                this.setupBuiltinRecognizers();
                this.setupCustomRecognizers();
                this.updateEnabled(this.enabled);
            }
        },
        destroyed: function destroyed() {
            if (!this.$isServer) {
                this.hammer.destroy();
            }
        },
        watch: {
            enabled: {
                deep: true,
                handler: function handler() {
                    var args = [], len = arguments.length;
                    while (len--) args[len] = arguments[len];
                    (ref = this).updateEnabled.apply(ref, args);
                    var ref;
                }
            }
        },
        methods: {
            setupBuiltinRecognizers: function setupBuiltinRecognizers() {
                var this$1 = this;
                for (var i = 0; i < gestures.length; i++) {
                    var gesture = gestures[i];
                    if (this$1._events[gesture]) {
                        var mainGesture = gestureMap[gesture];
                        var options = assign({}, (config[mainGesture] || {}), this$1[(mainGesture + "Options")]);
                        this$1.addRecognizer(mainGesture, options);
                        this$1.addEvent(gesture);
                    }
                }
            },
            setupCustomRecognizers: function setupCustomRecognizers() {
                var this$1 = this;
                var gestures$$1 = Object.keys(customEvents);
                for (var i = 0; i < gestures$$1.length; i++) {
                    var gesture = gestures$$1[i];
                    if (this$1._events[gesture]) {
                        var opts = customEvents[gesture];
                        var localCustomOpts = this$1[(gesture + "Options")] || {};
                        var options = assign({}, opts, localCustomOpts);
                        this$1.addRecognizer(gesture, options, {mainGesture: options.type});
                        this$1.addEvent(gesture);
                    }
                }
            },
            addRecognizer: function addRecognizer(gesture, options, ref) {
                if (ref === void 0) ref = {};
                var mainGesture = ref.mainGesture;
                if (!this.recognizers[gesture]) {
                    var recognizer = new Hammer[capitalize(mainGesture || gesture)](guardDirections(options));
                    this.recognizers[gesture] = recognizer;
                    this.hammer.add(recognizer);
                    recognizer.recognizeWith(this.hammer.recognizers);
                }
            },
            addEvent: function addEvent(gesture) {
                var this$1 = this;
                this.hammer.on(gesture, function (e) {
                    return this$1.$emit(gesture, e);
                });
            },
            updateEnabled: function updateEnabled(newVal, oldVal) {
                var this$1 = this;
                if (newVal === true) {
                    this.enableAll();
                } else if (newVal === false) {
                    this.disableAll();
                } else if (typeof newVal === 'object') {
                    var keys = Object.keys(newVal);
                    for (var i = 0; i < keys.length; i++) {
                        var event = keys[i];
                        if (this$1.recognizers[event]) {
                            newVal[event]
                                ? this$1.enable(event)
                                : this$1.disable(event);
                        }
                    }
                }
            },
            enable: function enable(r) {
                var recognizer = this.recognizers[r];
                if (!recognizer.options.enable) {
                    recognizer.set({enable: true});
                }
            },
            disable: function disable(r) {
                var recognizer = this.recognizers[r];
                if (recognizer.options.enable) {
                    recognizer.set({enable: false});
                }
            },
            toggle: function toggle(r) {
                var recognizer = this.recognizers[r];
                if (recognizer) {
                    recognizer.options.enable
                        ? this.disable(r)
                        : this.enable(r);
                }
            },
            enableAll: function enableAll(r) {
                this.toggleAll({enable: true});
            },
            disableAll: function disableAll(r) {
                this.toggleAll({enable: false});
            },
            toggleAll: function toggleAll(ref) {
                var this$1 = this;
                var enable = ref.enable;
                var keys = Object.keys(this.recognizers);
                for (var i = 0; i < keys.length; i++) {
                    var r = this$1.recognizers[keys[i]];
                    if (r.options.enable !== enable) {
                        r.set({enable: enable});
                    }
                }
            },
            isEnabled: function isEnabled(r) {
                return this.recognizers[r] && this.recognizers[r].options.enable
            }
        },
        render: function render(h) {
            return h(this.tag, {}, this.$slots.default)
        }
    };

    var installed = false;
    var vueTouch = {config: config, customEvents: customEvents};
    vueTouch.install = function install(Vue, opts) {
        if (opts === void 0) opts = {};
        var name = opts.name || 'v-touch';
        Vue.component(name, assign(Component, {name: name}));
        installed = true;
    }.bind(vueTouch);
    vueTouch.registerCustomEvent = function registerCustomEvent(event, options) {
        if (options === void 0) options = {};
        if (installed) {
            console.warn(("\n      [vue-touch]: Custom Event '" + event + "' couldn't be added to vue-touch.\n      Custom Events have to be registered before installing the plugin.\n      "));
            return
        }
        options.event = event;
        customEvents[event] = options;
        Component.props[(event + "Options")] = {
            type: Object,
            default: function default$1() {
                return {}
            }
        };
    }.bind(vueTouch);
    vueTouch.component = Component;

    if (typeof exports == "object") {
        module.exports = vueTouch;
    } else if (typeof define == "function" && define.amd) {
        define([], function () {
            return vueTouch
        });
    } else if (typeof window !== 'undefined' && window.Vue) {
        window.VueTouch = vueTouch;
        Vue.use(vueTouch);
    }

})));


});