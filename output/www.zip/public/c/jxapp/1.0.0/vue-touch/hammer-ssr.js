define('jxapp/1.0.0/vue-touch/hammer-ssr.js', function(require, exports, module){module.exports = function Hammer() {
  console.log(`[vue-touch] Your should never see this message.
    When you do, your code tried to call 'new Hammer(), but your app has included a stub for HammerJS, provided by vue-touch, instead of the actual HammerJS library.
  `)
}


});