define('jxapp/1.0.0/examsLocal/examsLocal.js', function(require, exports, module){/**
 * Created by lei on 2017/7/25.
 */
var Ces = require('ces');
var Cui = require('cui');
var Collect = require('examCollect');

module.exports = {
    template: "<transition name=\"fold\">\n    <v-touch v-on:swipeleft=\"nextAnswer\" v-on:swiperight=\"upAnswer\" class=\"touchClass\">\n        <div class=\"examsLocal\" >\n            <div class=\"question-content\" >\n                <div class=\"question\">\n                    <div class=\"question-item\">\n                        <div class=\"question-type\">\n                            <span v-if=\"list.optiontype == 0\">判断题</span>\n                            <span v-if=\"list.optiontype == 1\">单选题</span>\n                            <span v-if=\"list.optiontype == 2\">多选题</span>\n                        </div>\n                        <span class=\"item\">\n                               {{list.question}}\n                            </span>\n                    </div>\n                    <div v-if=\"list.mediacontent\" class=\"img-content\">\n                        <img   v-if=\"list.mediatype == 1\" :src=\"list.mediacontent\" alt=\"\">\n\n                        <video   v-if=\"list.mediatype == 2\" :src=\"list.mediacontent\"  controls  >\n                            您的浏览器不支持 HTML5 video 标签。\n                        </video>\n                    </div>\n                </div>\n                <div class=\"answer\">\n                    <div  v-if=\"list.optiontype !=2 \" >\n                        <cui-radio v-model=\"answer\" :options='list.options' :key=\"list.options.value\"></cui-radio>\n                    </div>\n                    <div v-else >\n                        <cui-checklist  v-model=\"checklist\"  :options='list.options' :key=\"list.options.value\"></cui-checklist>\n                    </div>\n                </div>\n                <div class=\"explain\" v-show=\"explainShow\">\n                    <div>答案: <span >{{list.answer}}</span></div>\n                    <div class=\"detail-desc\">详细解释:{{list.explain}}</div>\n                </div>\n                <cui-button size=\"normal\" class=\"cancel-btn\"  type=\"primary\" @click.native=\"removeQ\" v-show=\"showStart\">删除</cui-button>\n            </div>\n        </div>\n    </v-touch>\n</transition>",
    data: function () {
        return {
            list:{
                options:[]
            },
            answer:'',  //选择答案
            checklist:[], //多选题答案
            explainShow:false, //解释
            rightAnswer:'', //正确答案
            indexId:0,
            showStart:true,
            qLength:0,
            localParams:{}
        }
    },
    methods: {
        removeQ:function(){
            if(this.showStart){
                this.showStart =false;
                //todo  取消收藏此问题
                console.log('removeQ====',this.qLength);
                Collect.removeQ(this.list,this.localParams);
                this.qLength =Collect.getQLength(this.localParams);
                if(this.qLength>0){
                    this.loadQ(this.indexId);
                }else{
                    Cui.Toast({
                        message: "没有收藏题目",
                        position: 'bottom'
                    });
                    this.$router.push({'path':'/exercise'})
                }
                this.showStart=true;
            }
        },
        loadQ:function (indexId) {
            if(this.qLength > indexId){
                this.list =  Collect.getQ(indexId,this.localParams);
            }
        },
        nextAnswer:function(){
                if( this.list.answer == this.checklist.sort().join(",") ||
                    this.list.answer == this.answer || this.explainShow ){
                    this.answer ='';
                    this.checklist =[];
                  //  Collect.removeQ(this.list,this.localParams);
                    var seq = parseInt(this.indexId) + 1 ;
                    console.log(this.qLength,seq)
                    if(this.qLength> seq ){
                        this.indexId = this.indexId +1;
                        this.loadQ(this.indexId);
                        this.showStart=true;
                        this.explainShow =false;

                    }else{
                        Cui.Toast({
                            message: "最后一题了",
                            position: 'bottom'
                        });
                    }
                    //正确删除
                    Collect.removeQ(this.list,this.localParams);
                    //this.$router.push({'path':'/exercise'})
                }else{
                    this.explainShow =true;
                }
        },
        upAnswer:function(){
            if(this.indexId >0 && this.qLength > 0){
                this.indexId = this.indexId - 1;
                this.loadQ(this.indexId);
                this.showStart=true;
                this.explainShow =false;
            }else{
                    Cui.Toast({
                        message: "已经是第一题了",
                        position: 'bottom'
                    });
            }
        }
    },
    activated: function(){
        this.showStart=true;
        this.localParams = this.$route.query;
        this.indexId =this.localParams.questions ;
        this.qLength=0;
        this.qLength =Collect.getQLength(this.localParams);
        this.loadQ(this.indexId);
    }
};

});