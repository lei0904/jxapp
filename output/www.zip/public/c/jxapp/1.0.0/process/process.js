define('jxapp/1.0.0/process/process.js', function(require, exports, module){var Ces = require('ces');
var Cui = require('cui');
var Api = require('api');

module.exports = {
    template: "<div>\n    <div class=\"static_module\">\n        <div class=\"static_module_header\">\n            线下报名\n        </div>\n        <div class=\"static_module_content\">\n            <div class=\"static_module_content_item\">\n                门店填写报名信息，选择套餐，签订合同并备案，提交注册资料，完成体检流程。\n            </div>\n        </div>\n    </div>\n    <div class=\"static_module\">\n        <div class=\"static_module_header\">\n            科目一\n        </div>\n        <div class=\"static_module_content\">\n            <div class=\"static_module_content_item\">\n                学员在手机app上进行科目一学习&模拟测试，联系客服随时约考。考虑到科目一约考时间不固定，提供科目一未考试学员额外7小时的科目二训练学时（即在科目一考前也可以提前参加科目二学习，加快整体拿证速度）。\n            </div>\n        </div>\n    </div>\n    <div class=\"static_module\">\n        <div class=\"static_module_header\">\n            科目二\n        </div>\n        <div class=\"static_module_content\">\n            <div class=\"static_module_content_item\">\n                学员在手机app上预约科目二训练班次，线下参加小路考训练，提供接送服务。学员根据个人训练情况随时预约考试！\n            </div>\n        </div>\n    </div>\n    <div class=\"static_module\">\n        <div class=\"static_module_header\">\n            科目三\n        </div>\n        <div class=\"static_module_content\">\n            <div class=\"static_module_content_item\">\n                学员完成大路考训练后，学员根据个人训练情况随时预约考试。\n            </div>\n        </div>\n    </div>\n    <div class=\"static_module\">\n        <div class=\"static_module_header\">\n            科目四\n        </div>\n        <div class=\"static_module_content\">\n            <div class=\"static_module_content_item\">\n                学员在手机app上进行科目四学习&模拟测试，学员根据个人测试情况随时联系客服进行约考。\n            </div>\n        </div>\n    </div>\n    <div class=\"static_module\">\n        <div class=\"static_module_header\">\n            拿证\n        </div>\n        <div class=\"static_module_content\">\n            <div class=\"static_module_content_item\">\n                科目四当天即可拿证！\n            </div>\n        </div>\n    </div>\n\n</div>",
    data: function () {
        return {

        }
    },
    methods: {

    }
};

});