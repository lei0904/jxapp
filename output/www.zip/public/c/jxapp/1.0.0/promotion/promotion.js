define('jxapp/1.0.0/promotion/promotion.js', function(require, exports, module){var Ces = require('ces');
var Cui = require('cui');
var Api = require('api');

module.exports = {
    template: "<div>\n    <div class=\"highLightTitle\">\n        邀请好友，赚现金！！\n    </div>\n    <div class=\"promotion_img\">\n        <img src=\"/jxapp/1.0.0/lib/images/promotion.png\">\n    </div>\n    <div class=\"promotion_content\">\n        推荐一位新用户并完成报名，即可获得50元现金奖励，以此类推，上不封顶！学友好不赶紧行动起来！！\n    </div>\n    <div class=\"static_module\">\n        <div class=\"static_module_header\">\n            操作说明\n        </div>\n        <div class=\"static_module_content\">\n            <div class=\"static_module_content_item\">\n                1.完成缴费即可查看邀请码\n            </div>\n            <div class=\"static_module_content_item\">\n                2.邀请新用户并让他注册时填写你的邀请码\n            </div>\n            <div class=\"static_module_content_item\">\n                3.新用户完成缴费，你赚取现金\n            </div>\n        </div>\n    </div>\n\n</div>",
    data: function () {
        return {

        }
    },
    methods: {

    }
};

});