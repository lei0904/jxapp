define('jxapp/1.0.0/personal/index.js', function(require, exports, module){var Cui = require('cui');
var Ces = require('ces');
var Plugins = require('plugins');

module.exports = {
    template: "<div class=\"personal\">\n    <div class=\"atavar-content\">\n        <img :src=\"avatar\" alt=\"\" @click=\"select_method()\">\n        <div class=\"atavar-name\">路人甲</div>\n    </div>\n    <cui-cell title=\"预约记录\" icon=\"back\" is-link ></cui-cell>\n    <cui-cell title=\"接送记录\" icon=\"back\" is-link ></cui-cell>\n    <cui-cell title=\"我的邀请码\" :value=\"invite\" icon=\"back\"></cui-cell>\n\n    <div class=\"bottom_but\">\n        <cui-button type=\"primary\" @click.native=\"logout\">退出登录</cui-button>\n    </div>\n    <cui-actionsheet :actions=\"actions\" ref=\"imgSelect\"></cui-actionsheet>\n</div>",
    data: function () {
        return {
            accountId:'',
            avatar: '/jxapp/1.0.0/lib/images/avatar.png',
            name:'',
            invite:'',
            actions: [],
            money: 0,
            favsrc: '',
            showinfo:''
        }
    },
    activated: function () {

    },
    created: function () {
        var _this = this;
        _this.$api.LoginData.get(function (data) {
            var account = data['account'];
            console.log(account);
            _this.name = account.name;
            _this.invite = account.invite;
        });
    },
    methods:{
        logout: function () {
            var _this = this;
            Cui.MessageBox.confirm('确认退出登录吗？', '', {
                callback: function (action) {
                    if (action === 'confirm') {
                        _this.$api.post('api/logout', {}).then(function (rets) {
                            _this.$api.process(rets, function (rets) {
                                _this.$api.LoginData.remove();
                                _this.$router.push({ path: '/login' });
                            });
                        });
                    }
                }
            })
        },
        select_method:function () {
            this.$refs.imgSelect.currentValue = true;
        }
    },
    mounted:function () {
        this.actions = [
            {
                name: '拍照',
                method: this.takePhoto
            },
            {
                name:'从相册选择',
                method:this.selectPhoto
            }
        ]
    }
};

});