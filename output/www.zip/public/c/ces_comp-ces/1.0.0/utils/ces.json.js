define('ces_comp-ces/1.0.0/utils/ces.json.js', function(require, exports, module){var JSON = (function () {

    return {
        serialize: function (item) {
            return JSON.stringify(item);
        },
        // fix for "illegal access" error on Android when JSON.parse is
        // passed null
        deserialize: function (data) {
            return data && JSON.parse(data);
        }
    }
})();

module.exports = JSON;

});