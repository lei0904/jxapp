define('ces_comp-ces/1.0.0/modules.js', function(require, exports, module){module.exports = function (Ces) {
    /* ----------- core ----------- */
    var Config = require('ces_comp-ces/1.0.0/core/ces.config.js');
    var JSBridge = require('ces_comp-ces/1.0.0/core/ces.jsbridge.js');
    var WebCache = require('ces_comp-ces/1.0.0/core/ces.webcache.js');
    var Page = require('ces_comp-ces/1.0.0/core/ces.page.js');

    Ces.Config = Config;
    Ces.JSBridge = JSBridge;
    Ces.WebCache = WebCache;
    Ces.Page = Page;


    /* ----------- plugins ----------- */
    var Plugins = require('ces_comp-ces/1.0.0/plugins/ces.plugins.js');

    Ces.Plugins = Plugins;

    /* ----------- utils ----------- */
    var DateTime = require('ces_comp-ces/1.0.0/utils/ces.datetime.js');
    var Utils = require('ces_comp-ces/1.0.0/utils/ces.utils.js');

    Ces.DateTime = DateTime;
    Ces.Utils = Utils;
};



});