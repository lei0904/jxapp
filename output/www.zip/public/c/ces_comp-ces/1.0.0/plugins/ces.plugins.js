define('ces_comp-ces/1.0.0/plugins/ces.plugins.js', function(require, exports, module){var Plugins = (function () {
    return {
        module: 'Plugins'
    }
})();

var Http = require('ces_comp-ces/1.0.0/plugins/http.js');
var Camera = require('ces_comp-ces/1.0.0/plugins/camera.js');
var Cache = require('ces_comp-ces/1.0.0/plugins/cache.js');
var Scan = require('ces_comp-ces/1.0.0/plugins/scan.js');
var nativeApi = require('ces_comp-ces/1.0.0/plugins/nativeApi.js');

Plugins.Http = Http;
Plugins.Camera = Camera;
Plugins.Cache = Cache;
Plugins.Scan = Scan;
Plugins.nativeApi = nativeApi;

module.exports = Plugins;

});