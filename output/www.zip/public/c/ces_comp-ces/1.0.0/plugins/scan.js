define('ces_comp-ces/1.0.0/plugins/scan.js', function(require, exports, module){var JSBridge = require('ces_comp-ces/1.0.0/core/ces.jsbridge.js');

var Scan = (function () {

    return {
        call: function (callback) {
            JSBridge.callHandler('CesErWeiPlugin', ['1'], function (rets) {
                callback && callback(rets);
            });
        }
    }
})();

module.exports = Scan;

});