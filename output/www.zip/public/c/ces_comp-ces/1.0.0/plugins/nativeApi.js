define('ces_comp-ces/1.0.0/plugins/nativeApi.js', function(require, exports, module){/**
 * Created by lei on 2017/7/13.
 */
var JSBridge = require('ces_comp-ces/1.0.0/core/ces.jsbridge.js');

var nativeApi = (function () {

    var _questions = function (params,callback) {
        JSBridge.callHandler('question', params,function (rets) {
            callback && callback(rets);
        });
    }

    return {
        questions:_questions
    }
})();

module.exports = nativeApi;

});