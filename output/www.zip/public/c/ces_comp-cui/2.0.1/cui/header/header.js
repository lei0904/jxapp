define('ces_comp-cui/2.0.1/cui/header/header.js', function(require, exports, module){/**
 * cui-header
 * @module components/header
 * @desc 顶部导航
 * @param {boolean} [fixed=false] - 固定顶部
 * @param {string} [title] - 标题
 * @param {slot} [left] - 显示在左侧区域
 * @param {slot} [right] - 显示在右侧区域
 *
 * @example
 * <cui-header title="我是标题" fixed>
 *   <cui-button slot="left" icon="back" @click="handleBack">返回</cui-button>
 *   <cui-button slot="right" icon="more"></cui-button>
 * </cui-header>
 */
module.exports = {
    name: 'cui-header',

    template: "<header\n        class=\"cui-header\"\n        :class=\"{ 'is-fixed': fixed }\">\n    <div class=\"cui-header-button is-left\">\n        <slot name=\"left\"></slot>\n    </div>\n    <h1 class=\"cui-header-title\" v-text=\"title\"></h1>\n    <div class=\"cui-header-button is-right\">\n        <slot name=\"right\"></slot>\n    </div>\n</header>",

    props: {
        fixed: Boolean,
        title: String
    }
};

});