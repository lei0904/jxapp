define('ces_comp-cui/2.0.1/cui/search/search.js', function(require, exports, module){var XCell = require('ces_comp-cui/2.0.1/cui/cell/cell.js');

/**
 * cui-search
 * @module components/search
 * @desc 搜索框
 * @param {string} value - 绑定值
 * @param {string} [cancel-text=取消] - 取消按钮文字
 * @param {string} [placeholder=取消] - 搜索框占位内容
 * @param {string[]} [result] - 结果列表
 * @param {slot} 结果列表
 *
 * @example
 * <cui-search :value.sync="value" :result.sync="result"></cui-search>
 * <cui-search :value.sync="value">
 *   <cui-cell v-for="item in result" :title="item"></cui-cell>
 * </cui-search>
 */
module.exports = {
    name: 'cui-search',

    template: "<div class=\"cui-search\">\n    <div class=\"cui-searchbar\">\n        <div class=\"cui-searchbar-inner\">\n            <i class=\"cesui cesui-search\" v-show=\"visible\"></i>\n            <input\n                    ref=\"input\"\n                    @click=\"visible = true\"\n                    type=\"search\"\n                    v-model=\"currentValue\"\n                    :placeholder=\"visible ? placeholder : ''\"\n                    class=\"cui-searchbar-core\">\n        </div>\n        <a\n                class=\"cui-searchbar-cancel\"\n                @click=\"visible = false, currentValue = ''\"\n                v-show=\"visible\"\n                v-text=\"cancelText\">\n        </a>\n        <label\n                @click=\"visible = true, $refs.input.focus()\"\n                class=\"cui-searchbar-placeholder\"\n                v-show=\"!visible\">\n            <i class=\"cesui cesui-search\"></i>\n            <span class=\"cui-searchbar-text\" v-text=\"placeholder\"></span>\n        </label>\n    </div>\n    <div class=\"cui-search-list\" v-show=\"currentValue\">\n        <div class=\"cui-search-list-warp\">\n            <slot>\n                <x-cell v-for=\"item in result\" :key=\"$index\" track-by=\"$index\" :title=\"item\"></x-cell>\n            </slot>\n        </div>\n    </div>\n</div>",

    data: function() {
        return {
            visible: false,
            currentValue: this.value
        };
    },

    components: {
        'x-cell': XCell
    },

    watch: {
        currentValue: function(val) {
            this.$emit('input', val);
        }
    },

    props: {
        value: String,
        cancelText: {
            default: '取消'
        },
        placeholder: {
            default: '搜索'
        },
        result: Array
    }
};

});