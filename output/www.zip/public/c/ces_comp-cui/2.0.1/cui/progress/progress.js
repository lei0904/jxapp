define('ces_comp-cui/2.0.1/cui/progress/progress.js', function(require, exports, module){module.exports = {
    name: 'cui-progress',

    template: "<div class=\"cui-progress\">\n    <slot name=\"start\"></slot>\n    <div class=\"cui-progress-content\">\n        <div class=\"cui-progress-runway\" :style=\"{ height: barHeight + 'px' }\"></div>\n        <div class=\"cui-progress-progress\" :style=\"{ width: value + '%', height: barHeight + 'px' }\"></div>\n    </div>\n    <slot name=\"end\"></slot>\n</div>",

    props: {
        value: Number,
        barHeight: {
            type: Number,
            default: 3
        }
    }
};

});