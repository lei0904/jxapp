define('ces_comp-cui/2.0.1/cui/switch/switch.js', function(require, exports, module){/**
 * cui-switch
 * @module components/switch
 * @desc 切换按钮
 * @param {boolean} [value] - 绑定值，支持双向绑定
 * @param {slot} - 显示内容
 *
 * @example
 * <cui-switch v-model="value"></cui-switch>
 */
module.exports = {
    name: 'cui-switch',

    template: "<div class=\"cui-switch\">\n    <input class=\"cui-switch-input\" type=\"checkbox\" v-model=\"currentValue\">\n    <span class=\"cui-switch-core\" v-on:click=\"currentValueChange\"></span>\n    <div class=\"cui-switch-label\"><slot></slot></div>\n</div>",

    props: {
        value: Boolean
    },

    data: function() {
        console.log(this.value);
        return {
            currentValue: this.value
        };
    },

    methods: {
        currentValueChange: function () {
            this.currentValue = !this.value;
        }
    },

    watch: {
        value: function(val) {
            this.currentValue = val;
        },

        currentValue: function(val) {
            this.$emit('input', val);
        }
    }
};

});