define('ces_comp-cui/2.0.1/cui/spinner/spinner/triple-bounce.js', function(require, exports, module){var common = require('ces_comp-cui/2.0.1/cui/spinner/spinner/common.js');

module.exports = {
    name: 'triple-bounce',

    template: "<div class=\"cui-spinner-triple-bounce\">\n    <div class=\"cui-spinner-triple-bounce-bounce1\" :style=\"bounceStyle\"></div>\n    <div class=\"cui-spinner-triple-bounce-bounce2\" :style=\"bounceStyle\"></div>\n    <div class=\"cui-spinner-triple-bounce-bounce3\" :style=\"bounceStyle\"></div>\n</div>",

    mixins: [common],

    computed: {
        spinnerSize: function() {
            return ((this.size || this.$parent.size || 28) / 3) + 'px';
        },

        bounceStyle: function() {
            return {
                width: this.spinnerSize,
                height: this.spinnerSize,
                backgroundColor: this.spinnerColor
            };
        }
    }
};

});