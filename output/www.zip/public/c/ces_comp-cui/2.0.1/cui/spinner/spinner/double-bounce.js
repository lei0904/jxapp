define('ces_comp-cui/2.0.1/cui/spinner/spinner/double-bounce.js', function(require, exports, module){var common = require('ces_comp-cui/2.0.1/cui/spinner/spinner/common.js');

module.exports = {
    name: 'double-bounce',

    template: "<div class=\"cui-spinner-double-bounce\" :style=\"{\n      width: spinnerSize,\n      height: spinnerSize\n    }\">\n    <div class=\"cui-spinner-double-bounce-bounce1\" :style=\"{ backgroundColor: spinnerColor }\"></div>\n    <div class=\"cui-spinner-double-bounce-bounce2\" :style=\"{ backgroundColor: spinnerColor }\"></div>\n</div>",

    mixins: [common]
};

});