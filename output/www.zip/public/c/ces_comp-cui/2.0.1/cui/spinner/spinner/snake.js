define('ces_comp-cui/2.0.1/cui/spinner/spinner/snake.js', function(require, exports, module){var common = require('ces_comp-cui/2.0.1/cui/spinner/spinner/common.js');

module.exports = {
    name: 'snake',

    template: "<div class=\"cui-spinner-snake\" :style=\"{\n    'border-top-color': spinnerColor,\n    'border-left-color': spinnerColor,\n    'border-bottom-color': spinnerColor,\n    'height': spinnerSize,\n    'width': spinnerSize\n    }\">\n</div>",

    mixins: [common]
}

});