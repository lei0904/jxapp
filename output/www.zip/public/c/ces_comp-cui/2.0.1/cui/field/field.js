define('ces_comp-cui/2.0.1/cui/field/field.js', function(require, exports, module){var XCell = require('ces_comp-cui/2.0.1/cui/cell/cell.js');
var Clickoutside = require('ces_comp-cui/2.0.1/clickoutside/clickoutside.js');

/**
 * cui-field
 * @desc 编辑器，依赖 cell
 * @module components/field
 *
 * @param {string} [type=text] - field 类型，接受 text, textarea 等
 * @param {string} [label] - 标签
 * @param {string} [rows] - textarea 的 rows
 * @param {string} [placeholder] - placeholder
 * @param {string} [disabled] - disabled
 * @param {string} [readonly] - readonly
 * @param {string} [state] - 表单校验状态样式，接受 error, warning, success
 *
 * @example
 * <cui-field v-model="value" label="用户名"></cui-field>
 * <cui-field v-model="value" label="密码" placeholder="请输入密码"></cui-field>
 * <cui-field v-model="value" label="自我介绍" placeholder="自我介绍" type="textarea" rows="4"></cui-field>
 * <cui-field v-model="value" label="邮箱" placeholder="成功状态" state="success"></cui-field>
 */
module.exports = {
    name: 'cui-field',

    template: "<x-cell\n        class=\"cui-field\"\n        :title=\"label\"\n        v-clickoutside=\"doCloseActive\"\n        :class=\"[{\n      'is-textarea': type === 'textarea',\n      'is-nolabel': !label\n    }]\">\n    <textarea\n            ref=\"textarea\"\n            class=\"cui-field-core\"\n            :placeholder=\"placeholder\"\n            v-if=\"type === 'textarea'\"\n            :rows=\"rows\"\n            :disabled=\"disabled\"\n            :readonly=\"readonly\"\n            v-model=\"currentValue\">\n    </textarea>\n    <input\n            ref=\"input\"\n            class=\"cui-field-core\"\n            :placeholder=\"placeholder\"\n            :name=\"name\"\n            :number=\"type === 'number'\"\n            v-else\n            :type=\"type\"\n            @focus=\"active = true\"\n            :disabled=\"disabled\"\n            :readonly=\"readonly\"\n            :value=\"currentValue\"\n            @input=\"handleInput\">\n    <div\n            @click=\"handleClear\"\n            class=\"cui-field-clear\"\n            v-if=\"!disableClear\"\n            v-show=\"currentValue && type !== 'textarea' && active\">\n        <i class=\"cesui cesui-field-error\"></i>\n    </div>\n    <span class=\"cui-field-state\" v-if=\"state\" :class=\"['is-' + state]\">\n      <i class=\"cesui\" :class=\"['cesui-field-' + state]\"></i>\n    </span>\n    <div class=\"cui-field-other\">\n        <slot></slot>\n    </div>\n</x-cell>",

    data: function() {
        return {
            active: false,
            currentValue: this.value
        };
    },

    directives: {
        Clickoutside: Clickoutside
    },

    props: {
        type: {
            type: String,
        default: 'text'
        },
        rows: String,
            label: String,
            placeholder: String,
            name: String,
            readonly: Boolean,
            disabled: Boolean,
            disableClear: Boolean,
            state: {
            type: String,
        default: 'default'
        },
        value: {},
        attr: Object
    },

    components: { 'x-cell' : XCell },

    methods: {
        doCloseActive: function() {
            this.active = false;
        },

        handleInput: function(evt) {
            this.currentValue = evt.target.value;
        },

        handleClear: function() {
            if (this.disabled || this.readonly) return;
            this.currentValue = '';
        }
    },

    watch: {
        value: function(val) {
            this.currentValue = val;
        },

        currentValue: function(val) {
            this.$emit('input', val);
        },

        attr: {
            immediate: true,
                handler: function(attrs) {
                    this.$nextTick(function() {
                        var target = [this.$refs.input, this.$refs.textarea];
                        target.forEach(function(el) {
                            if (!el || !attrs) return;
                        Object.keys(attrs).map(function(name){
                            el.setAttribute(name, attrs[name])
                        });
                    });
                });
            }
        }
    }
};

});