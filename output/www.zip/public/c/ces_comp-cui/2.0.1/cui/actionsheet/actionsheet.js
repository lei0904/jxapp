define('ces_comp-cui/2.0.1/cui/actionsheet/actionsheet.js', function(require, exports, module){var Popup = require('ces_comp-cui/2.0.1/vue-popup/vue-popup.js');
var bus = require('ces_comp-cui/2.0.1/vue-event-bus/vue-event-bus.js');

module.exports = {
    name: 'cui-actionsheet',

    template: "<transition name=\"actionsheet-float\">\n    <div v-show=\"currentValue\" class=\"cui-actionsheet\">\n        <ul class=\"cui-actionsheet-list\" :style=\"{ 'margin-bottom': cancelText ? '5px' : '0' }\">\n            <li v-for=\"item in actions\" class=\"cui-actionsheet-listitem\" @click=\"itemClick(item)\">{{ item.name }}</li>\n        </ul>\n        <a class=\"cui-actionsheet-button\" @click=\"currentValue = false\" v-if=\"cancelText\">{{ cancelText }}</a>\n    </div>\n</transition>",

    mixins: [Popup],

    props: {
        modal: {
            default: true
        },

        modalFade: {
            default: false
        },

        lockScroll: {
            default: false
        },

        closeOnClickModal: {
            default: true
        },

        cancelText: {
            type: String,
            default: '取消'
        },

        actions: {
            type: Array,
            default: []
        }
    },

    data: function () {
        return {
            currentValue: false
        };
    },

    created: function () {
        var _this = this;
        bus.$on('doClose', function () {
            _this.currentValue = false;
        })
    },

    watch: {
        currentValue: function (val) {
            this.visible = val;
            this.$emit('input', val);
        },

        value: function (val) {
            this.currentValue = val;
        }
    },

    methods: {
        itemClick: function (item) {
            if (item.method && typeof item.method === 'function') {
                item.method();
            }
            this.currentValue = false;
        }
    }
};

});