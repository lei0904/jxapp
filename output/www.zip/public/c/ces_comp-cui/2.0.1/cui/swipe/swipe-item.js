define('ces_comp-cui/2.0.1/cui/swipe/swipe-item.js', function(require, exports, module){module.exports =  {
    name: 'cui-swipe-item',

    template: "<div class=\"cui-swipe-item\">\n    <slot></slot>\n</div>",

    mounted: function() {
        this.$parent && this.$parent.swipeItemCreated(this);
    },

    destroyed: function() {
        this.$parent && this.$parent.swipeItemDestroyed(this);
    }
};

});