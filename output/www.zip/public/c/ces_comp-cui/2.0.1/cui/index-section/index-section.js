define('ces_comp-cui/2.0.1/cui/index-section/index-section.js', function(require, exports, module){module.exports = {
    name: 'cui-index-section',

    template: "<li class=\"cui-indexsection\">\n    <p class=\"cui-indexsection-index\">{{ index }}</p>\n    <ul>\n        <slot></slot>\n    </ul>\n</li>",

    props: {
        index: {
            type: String,
            required: true
        }
    },

    mounted: function() {
        this.$parent.sections.push(this);
    },

    beforeDestroy: function() {
        var index = this.$parent.sections.indexOf(this);
        if (index > -1) {
            this.$parent.sections.splice(index, 1);
        }
    }
};

});