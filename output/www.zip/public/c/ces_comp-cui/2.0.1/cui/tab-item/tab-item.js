define('ces_comp-cui/2.0.1/cui/tab-item/tab-item.js', function(require, exports, module){module.exports = {
    name: 'cui-tab-item',

    template: "<a class=\"cui-tab-item\"\n   @click=\"$parent.$emit('input', id)\"\n   :class=\"{ 'is-selected': $parent.value === id }\">\n    <div class=\"cui-tab-item-icon\"><slot name=\"icon\"></slot></div>\n    <div class=\"cui-tab-item-label\"><slot></slot></div>\n</a>",

    props: ['id']
};

});