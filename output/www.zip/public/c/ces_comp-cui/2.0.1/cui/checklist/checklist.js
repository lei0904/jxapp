define('ces_comp-cui/2.0.1/cui/checklist/checklist.js', function(require, exports, module){var XCell =require('ces_comp-cui/2.0.1/cui/cell/cell.js');

/**
 * cui-checklist
 * @module components/checklist
 * @desc 复选框列表，依赖 cell 组件
 *
 * @param {(string[]|object[])} options - 选项数组，可以传入 [{label: 'label', value: 'value', disabled: true}] 或者 ['ab', 'cd', 'ef']
 * @param {string[]} value - 选中值的数组
 * @param {string} title - 标题
 * @param {number} [max] - 最多可选的个数
 * @param {string} [align=left] - checkbox 对齐位置，`left`, `right`
 *
 *
 * @example
 * <cui-checklist :v-model="value" :options="['a', 'b', 'c']"></cui-checklist>
 */
module.exports = {
    name: 'cui-checklist',

    template: "<div class=\"cui-checklist\" :class=\"{ 'is-limit': max <= currentValue.length }\">\n    <label class=\"cui-checklist-title\" v-text=\"title\"></label>\n    <x-cell v-for=\"option in options\">\n        <label class=\"cui-checklist-label\" slot=\"title\">\n        <span\n                :class=\"{'is-right': align === 'right'}\"\n                class=\"cui-checkbox\">\n          <input\n                  class=\"cui-checkbox-input\"\n                  type=\"checkbox\"\n                  v-model=\"currentValue\"\n                  :disabled=\"option.disabled\"\n                  :value=\"option.value || option\">\n          <span class=\"cui-checkbox-core\"></span>\n        </span>\n            <span class=\"cui-checkbox-label\" v-text=\"option.label || option\"></span>\n        </label>\n    </x-cell>\n</div>",

    props: {
        max: Number,
        title: String,
        align: String,
        options: {
            type: Array,
            required: true
        },
        value: Array
    },

    components: {
        XCell: XCell
    },

    data: function() {
        return {
            currentValue: this.value
        };
    },

    computed: {
        limit: function() {
            return this.max < this.currentValue.length;
        }
    },

    watch: {
        value: function(val) {
            this.currentValue = val;
        },

        currentValue: function(val) {
            if (this.limit) {
                val.pop();
            }
            this.$emit('input', val);
        }
    }
};

});