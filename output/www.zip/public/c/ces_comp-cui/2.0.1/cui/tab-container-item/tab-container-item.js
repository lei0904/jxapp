define('ces_comp-cui/2.0.1/cui/tab-container-item/tab-container-item.js', function(require, exports, module){
/**
 * cui-tab-container-item
 * @desc 搭配 tab-container 使用
 * @module components/tab-container-item
 *
 * @param {number|string} [id] - 该项的 id
 *
 * @example
 * <cui-tab-container v-model="selected">
 *   <cui-tab-container-item id="1"> 内容A </cui-tab-container-item>
 *   <cui-tab-container-item id="2"> 内容B </cui-tab-container-item>
 *   <cui-tab-container-item id="3"> 内容C </cui-tab-container-item>
 * </cui-tab-container>
 */
module.exports = {
    name: 'cui-tab-container-item',

    template: "<div\n        v-show=\"$parent.swiping || id === $parent.currentActive\"\n        class=\"cui-tab-container-item\">\n    <slot></slot>\n</div>",

    props: ['id']
};


});