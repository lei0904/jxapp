define('ces_comp-cui/2.0.1/cui/radio/radio.js', function(require, exports, module){var XCell =require('ces_comp-cui/2.0.1/cui/cell/cell.js') ;

/**
 * cui-radio
 * @module components/radio
 * @desc 单选框列表，依赖 cell 组件
 *
 * @param {string[], object[]} options - 选项数组，可以传入 [{label: 'label', value: 'value', disabled: true}] 或者 ['ab', 'cd', 'ef']
 * @param {string} value - 选中值
 * @param {string} title - 标题
 * @param {string} [align=left] - checkbox 对齐位置，`left`, `right`
 *
 * @example
 * <cui-radio v-model="value" :options="['a', 'b', 'c']"></cui-radio>
 */
module.exports =  {
    name: 'cui-radio',

    template: "<div class=\"cui-radiolist\">\n    <label class=\"cui-radiolist-title\" v-text=\"title\"></label>\n    <x-cell v-for=\"option in options\">\n        <label class=\"cui-radiolist-label\" slot=\"title\">\n        <span\n                :class=\"{'is-right': align === 'right'}\"\n                class=\"cui-radio\">\n          <input\n                  class=\"cui-radio-input\"\n                  type=\"radio\"\n                  v-model=\"currentValue\"\n                  :disabled=\"option.disabled\"\n                  :value=\"option.value || option\">\n          <span class=\"cui-radio-core\"></span>\n        </span>\n            <span class=\"cui-radio-label\" v-text=\"option.label || option\"></span>\n        </label>\n    </x-cell>\n</div>",

    props: {
        title: String,
        align: String,
        options: {
            type: Array,
            required: true
        },
        value: String
    },

    data:function() {
        return {
            currentValue: this.value
        };
    },

    watch: {
        value:function(val) {
            this.currentValue = val;
        },

        currentValue:function(val) {
            this.$emit('input', val);
        }
    },

    components: {
        XCell : XCell
    }
};

});