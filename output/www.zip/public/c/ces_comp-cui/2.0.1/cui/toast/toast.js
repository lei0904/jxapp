define('ces_comp-cui/2.0.1/cui/toast/toast.js', function(require, exports, module){var Vue = require('vue');

var ToastConstructor = Vue.extend({
    template: "<transition name=\"cui-toast-pop\">\n    <div class=\"cui-toast\" v-show=\"visible\" :class=\"customClass\" :style=\"{ 'padding': iconClass === '' ? '10px' : '20px' }\">\n        <i class=\"cui-toast-icon\" :class=\"iconClass\" v-if=\"iconClass !== ''\"></i>\n        <span class=\"cui-toast-text\" :style=\"{ 'padding-top': iconClass === '' ? '0' : '10px' }\">{{ message }}</span>\n    </div>\n</transition>",

    props: {
        message: String,
        className: {
            type: String,
            default: ''
        },
        position: {
            type: String,
            default: 'middle'
        },
        iconClass: {
            type: String,
            default: ''
        }
    },

    data: function() {
        return {
            visible: false
        };
    },

    computed: {
        customClass: function() {
            var classes = [];
            switch (this.position) {
                case 'top':
                    classes.push('is-placetop');
                    break;
                case 'bottom':
                    classes.push('is-placebottom');
                    break;
                default:
                    classes.push('is-placemiddle');
            }
            classes.push(this.className);

            return classes.join(' ');
        }
    }
});



var toastPool = [];

var getAnInstance = function() {
    if (toastPool.length > 0) {
        var instance = toastPool[0];
        toastPool.splice(0, 1);
        return instance;
    }
    return new ToastConstructor({
        el: document.createElement('div')
    });
};

var returnAnInstance = function(instance) {
    if (instance) {
        toastPool.push(instance);
    }
};

var removeDom = function(event) {
    if (event.target.parentNode) {
        event.target.parentNode.removeChild(event.target);
    }
};

ToastConstructor.prototype.close = function() {
    this.visible = false;
    this.$el.addEventListener('transitionend', removeDom);
    this.closed = true;
    returnAnInstance(this);
};

var Toast = function(options) {
    options = options || {};
    var duration = options.duration || 3000;

    var instance = getAnInstance();
    instance.closed = false;
    clearTimeout(instance.timer);
    instance.message = typeof options === 'string' ? options : options.message;
    instance.position = options.position || 'middle';
    instance.className = options.className || '';
    instance.iconClass = options.iconClass || '';

    document.body.appendChild(instance.$el);
    Vue.nextTick(function() {
        instance.visible = true;
        instance.$el.removeEventListener('transitionend', removeDom);
        instance.timer = setTimeout(function() {
            if (instance.closed) return;
            instance.close();
        }, duration);
    });
    return instance;
};

module.exports =Toast;



});