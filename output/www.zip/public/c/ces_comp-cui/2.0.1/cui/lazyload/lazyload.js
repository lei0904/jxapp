define('ces_comp-cui/2.0.1/cui/lazyload/lazyload.js', function(require, exports, module){var Lazyload = require('ces_comp-cui/2.0.1/vue-lazyload/vue-lazyload.js');
module.exports = Lazyload;

});