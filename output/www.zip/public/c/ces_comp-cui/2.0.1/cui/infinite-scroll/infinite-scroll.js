define('ces_comp-cui/2.0.1/cui/infinite-scroll/infinite-scroll.js', function(require, exports, module){var InfiniteScroll = require('ces_comp-cui/2.0.1/cui/infinite-scroll/directive.js');

var install = function(Vue) {
    Vue.directive('InfiniteScroll', InfiniteScroll);
};

if (window.Vue) {
    window.infiniteScroll = InfiniteScroll;
    Vue.use(install); // eslint-disable-line
}

InfiniteScroll.install = install;
module.exports = InfiniteScroll;

});