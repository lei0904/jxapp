define('ces_comp-cui/2.0.1/wind-dom/index.js', function(require, exports, module){var clazz = require('ces_comp-cui/2.0.1/wind-dom/class.js');
var event = require('ces_comp-cui/2.0.1/wind-dom/event.js');
var style= require('ces_comp-cui/2.0.1/wind-dom/style.js');
var create = require('ces_comp-cui/2.0.1/wind-dom/create.js');

module.exports = {
  on: event.on,
  off: event.off,
  once: event.once,
  getStyle: style.getStyle,
  setStyle: style.setStyle,
  removeClass: clazz.removeClass,
  addClass: clazz.addClass,
  hasClass: clazz.hasClass,
  create: create
};

});