define('ces_comp-cui/2.0.1/vue-event-bus/vue-event-bus.js', function(require, exports, module){var Vue = require('vue');

var vueEventBus = new Vue();

module.exports = vueEventBus;

});