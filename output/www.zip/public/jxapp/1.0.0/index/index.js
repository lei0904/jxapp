'use strict';

require.config({
    "cache": false,
    "urlPattern": "/c/%s",
    "comboPattern": "/co??%s",
    "version": "1.0.0",
    "name": "jxapp",
    "combo": false,
    "hash": "cb22428",
    "alias": {
        "vuerify": "ces_comp-vuerify/0.4.0/vuerify.js",
        "vue": "ces_comp-vue/2.0.3/vue.js",
        "v-vuerify": "ces_comp-v-vuerify/0.3.0/v-vuerify.js",
        "v-vuerify-next": "ces_comp-v-vuerify-next/0.2.0/v-vuerify-next.js",
        "simple-assign": "ces_comp-simple-assign/0.1.0/index.js",
        "es6-promise": "ces_comp-es6-promise/3.3.1/index.js",
        "vue-resource": "ces_comp-vue-resource/1.0.3/vue-resource.js",
        "vue-router": "ces_comp-vue-router/2.0.0/vue-router.js",
        "ces-vue-resource": "ces_comp-ces-vue-resource/1.0.0/index.js",
        "ces": "ces_comp-ces/1.0.0/ces.js",
        "cui": "ces_comp-cui/2.0.1/cui/cui.js",
        "api": "jxapp/1.0.0/api/api.js",
        "examCollect": "jxapp/1.0.0/examCollect/examCollect.js",
        "examRules": "jxapp/1.0.0/examRules/examRules.js",
        "examStorage": "jxapp/1.0.0/examStorage/examStorage.js",
        "exams": "jxapp/1.0.0/exams/exams.js",
        "examsDir": "jxapp/1.0.0/examsDir/examsDir.js",
        "examsLocal": "jxapp/1.0.0/examsLocal/examsLocal.js",
        "helper": "jxapp/1.0.0/helper/helper.js",
        "index": "jxapp/1.0.0/index/index.js",
        "moment": "jxapp/1.0.0/moment/moment.js",
        "notice": "jxapp/1.0.0/notice/notice.js",
        "plugins": "jxapp/1.0.0/plugins/plugins.js",
        "problem": "jxapp/1.0.0/problem/problem.js",
        "process": "jxapp/1.0.0/process/process.js",
        "promise": "jxapp/1.0.0/promise/promise.js",
        "routes": "jxapp/1.0.0/routes/routes.js",
        "success": "jxapp/1.0.0/success/success.js",
        "vee-validate": "jxapp/1.0.0/vee-validate/vee-validate.js",
        "vue-touch": "jxapp/1.0.0/vue-touch/vue-touch.js"
    },
    "deps": {
        "ces_comp-ces-vue-resource/1.0.0/index.js": [
            "ces",
            "vue",
            "vue-resource",
            "ces_comp-ces-vue-resource/1.0.0/qs.js",
            "cui"
        ],
        "ces_comp-ces-vue-resource/1.0.0/parse.js": [
            "ces_comp-ces-vue-resource/1.0.0/utils.js"
        ],
        "ces_comp-ces-vue-resource/1.0.0/qs.js": [
            "ces_comp-ces-vue-resource/1.0.0/stringify.js",
            "ces_comp-ces-vue-resource/1.0.0/parse.js",
            "ces_comp-ces-vue-resource/1.0.0/formats.js",
            "ces_comp-ces-vue-resource/1.0.0/utils.js"
        ],
        "ces_comp-ces-vue-resource/1.0.0/stringify.js": [
            "ces_comp-ces-vue-resource/1.0.0/utils.js",
            "ces_comp-ces-vue-resource/1.0.0/formats.js"
        ],
        "ces_comp-ces/1.0.0/ces.js": [
            "ces_comp-ces/1.0.0/modules.js"
        ],
        "ces_comp-ces/1.0.0/core/ces.page.js": [
            "ces_comp-ces/1.0.0/core/ces.config.js",
            "ces_comp-ces/1.0.0/core/ces.webcache.js",
            "ces_comp-ces/1.0.0/core/ces.jsbridge.js"
        ],
        "ces_comp-ces/1.0.0/modules.js": [
            "ces_comp-ces/1.0.0/core/ces.config.js",
            "ces_comp-ces/1.0.0/core/ces.jsbridge.js",
            "ces_comp-ces/1.0.0/core/ces.webcache.js",
            "ces_comp-ces/1.0.0/core/ces.page.js",
            "ces_comp-ces/1.0.0/plugins/ces.plugins.js",
            "ces_comp-ces/1.0.0/utils/ces.datetime.js",
            "ces_comp-ces/1.0.0/utils/ces.utils.js"
        ],
        "ces_comp-ces/1.0.0/plugins/cache.js": [
            "ces_comp-ces/1.0.0/core/ces.jsbridge.js",
            "ces_comp-ces/1.0.0/utils/ces.utils.js"
        ],
        "ces_comp-ces/1.0.0/plugins/camera.js": [
            "ces_comp-ces/1.0.0/core/ces.jsbridge.js",
            "ces_comp-ces/1.0.0/utils/ces.utils.js"
        ],
        "ces_comp-ces/1.0.0/plugins/ces.plugins.js": [
            "ces_comp-ces/1.0.0/plugins/http.js",
            "ces_comp-ces/1.0.0/plugins/camera.js",
            "ces_comp-ces/1.0.0/plugins/cache.js",
            "ces_comp-ces/1.0.0/plugins/scan.js",
            "ces_comp-ces/1.0.0/plugins/nativeApi.js"
        ],
        "ces_comp-ces/1.0.0/plugins/http.js": [
            "ces_comp-ces/1.0.0/core/ces.jsbridge.js"
        ],
        "ces_comp-ces/1.0.0/plugins/nativeApi.js": [
            "ces_comp-ces/1.0.0/core/ces.jsbridge.js"
        ],
        "ces_comp-ces/1.0.0/plugins/scan.js": [
            "ces_comp-ces/1.0.0/core/ces.jsbridge.js"
        ],
        "ces_comp-cui/2.0.1/cui/actionsheet/actionsheet.js": [
            "ces_comp-cui/2.0.1/vue-popup/vue-popup.js",
            "ces_comp-cui/2.0.1/vue-event-bus/vue-event-bus.js",
            "ces_comp-cui/2.0.1/cui/actionsheet/actionsheet.css"
        ],
        "ces_comp-cui/2.0.1/cui/address-picker/address-picker.js": [
            "ces_comp-cui/2.0.1/cui/picker/picker.js",
            "ces_comp-cui/2.0.1/cui/popup/popup.js",
            "ces_comp-cui/2.0.1/cui/address-picker/address-picker.css"
        ],
        "ces_comp-cui/2.0.1/cui/badge/badge.js": [
            "ces_comp-cui/2.0.1/cui/badge/badge.css"
        ],
        "ces_comp-cui/2.0.1/cui/button/button.js": [
            "ces_comp-cui/2.0.1/cui/button/button.css"
        ],
        "ces_comp-cui/2.0.1/cui/cell-swipe/cell-swipe.js": [
            "ces_comp-cui/2.0.1/wind-dom/event.js",
            "ces_comp-cui/2.0.1/cui/cell/cell.js",
            "ces_comp-cui/2.0.1/clickoutside/clickoutside.js",
            "ces_comp-cui/2.0.1/cui/cell-swipe/cell-swipe.css"
        ],
        "ces_comp-cui/2.0.1/cui/cell/cell.js": [
            "ces_comp-cui/2.0.1/cui/cell/cell.css"
        ],
        "ces_comp-cui/2.0.1/cui/checklist/checklist.js": [
            "ces_comp-cui/2.0.1/cui/cell/cell.js",
            "ces_comp-cui/2.0.1/cui/checklist/checklist.css"
        ],
        "ces_comp-cui/2.0.1/cui/cui.js": [
            "ces_comp-cui/2.0.1/cui/cui_lib/font/iconfont.css",
            "ces_comp-cui/2.0.1/cui/cui_lib/indexicon/font.css",
            "ces_comp-cui/2.0.1/cui/cui_lib/style.css",
            "vue",
            "ces_comp-cui/2.0.1/cui/toast/toast.js",
            "ces_comp-cui/2.0.1/cui/indicator/indicator.js",
            "ces_comp-cui/2.0.1/cui/loadmore/loadmore.js",
            "ces_comp-cui/2.0.1/cui/infinite-scroll/infinite-scroll.js",
            "ces_comp-cui/2.0.1/cui/message-box/message-box.js",
            "ces_comp-cui/2.0.1/cui/actionsheet/actionsheet.js",
            "ces_comp-cui/2.0.1/cui/popup/popup.js",
            "ces_comp-cui/2.0.1/cui/swipe/swipe.js",
            "ces_comp-cui/2.0.1/cui/swipe/swipe-item.js",
            "ces_comp-cui/2.0.1/cui/lazyload/lazyload.js",
            "ces_comp-cui/2.0.1/cui/range/range.js",
            "ces_comp-cui/2.0.1/cui/progress/progress.js",
            "ces_comp-cui/2.0.1/cui/picker/picker.js",
            "ces_comp-cui/2.0.1/cui/datetime-picker/datetime-picker.js",
            "ces_comp-cui/2.0.1/cui/address-picker/address-picker.js",
            "ces_comp-cui/2.0.1/cui/index-list/index-list.js",
            "ces_comp-cui/2.0.1/cui/index-section/index-section.js",
            "ces_comp-cui/2.0.1/cui/header/header.js",
            "ces_comp-cui/2.0.1/cui/tabbar/tabbar.js",
            "ces_comp-cui/2.0.1/cui/navbar/navbar.js",
            "ces_comp-cui/2.0.1/cui/button/button.js",
            "ces_comp-cui/2.0.1/cui/cell/cell.js",
            "ces_comp-cui/2.0.1/cui/cell-swipe/cell-swipe.js",
            "ces_comp-cui/2.0.1/cui/spinner/spinner.js",
            "ces_comp-cui/2.0.1/cui/tab-item/tab-item.js",
            "ces_comp-cui/2.0.1/cui/tab-container-item/tab-container-item.js",
            "ces_comp-cui/2.0.1/cui/tab-container/tab-container.js",
            "ces_comp-cui/2.0.1/cui/search/search.js",
            "ces_comp-cui/2.0.1/cui/switch/switch.js",
            "ces_comp-cui/2.0.1/cui/checklist/checklist.js",
            "ces_comp-cui/2.0.1/cui/radio/radio.js",
            "ces_comp-cui/2.0.1/cui/field/field.js",
            "ces_comp-cui/2.0.1/cui/badge/badge.js"
        ],
        "ces_comp-cui/2.0.1/cui/datetime-picker/datetime-picker.js": [
            "ces_comp-cui/2.0.1/cui/picker/picker.js",
            "ces_comp-cui/2.0.1/cui/popup/popup.js",
            "ces_comp-cui/2.0.1/cui/datetime-picker/datetime-picker.css"
        ],
        "ces_comp-cui/2.0.1/cui/field/field.js": [
            "ces_comp-cui/2.0.1/cui/cell/cell.js",
            "ces_comp-cui/2.0.1/clickoutside/clickoutside.js",
            "ces_comp-cui/2.0.1/cui/field/field.css"
        ],
        "ces_comp-cui/2.0.1/cui/header/header.js": [
            "ces_comp-cui/2.0.1/cui/header/header.css"
        ],
        "ces_comp-cui/2.0.1/cui/index-list/index-list.js": [
            "ces_comp-cui/2.0.1/cui/index-list/index-list.css"
        ],
        "ces_comp-cui/2.0.1/cui/index-section/index-section.js": [
            "ces_comp-cui/2.0.1/cui/index-section/index-section.css"
        ],
        "ces_comp-cui/2.0.1/cui/indicator/indicator.js": [
            "vue",
            "ces_comp-cui/2.0.1/cui/spinner/spinner.js",
            "ces_comp-cui/2.0.1/cui/indicator/indicator.css"
        ],
        "ces_comp-cui/2.0.1/cui/infinite-scroll/infinite-scroll.js": [
            "ces_comp-cui/2.0.1/cui/infinite-scroll/directive.js"
        ],
        "ces_comp-cui/2.0.1/cui/lazyload/lazyload.js": [
            "ces_comp-cui/2.0.1/vue-lazyload/vue-lazyload.js"
        ],
        "ces_comp-cui/2.0.1/cui/loadmore/loadmore.js": [
            "ces_comp-cui/2.0.1/cui/spinner/spinner.js",
            "ces_comp-cui/2.0.1/cui/loadmore/loadmore.css"
        ],
        "ces_comp-cui/2.0.1/cui/message-box/message-box.js": [
            "vue",
            "ces_comp-cui/2.0.1/vue-popup/vue-popup.js",
            "ces_comp-cui/2.0.1/cui/message-box/message-box.css"
        ],
        "ces_comp-cui/2.0.1/cui/navbar/navbar.js": [
            "ces_comp-cui/2.0.1/cui/navbar/navbar.css"
        ],
        "ces_comp-cui/2.0.1/cui/picker/picker-slot.js": [
            "ces_comp-cui/2.0.1/cui/picker/draggable.js",
            "ces_comp-cui/2.0.1/cui/picker/translate.js",
            "ces_comp-cui/2.0.1/wind-dom/event.js",
            "ces_comp-cui/2.0.1/wind-dom/class.js",
            "ces_comp-cui/2.0.1/mixins/emitter.js"
        ],
        "ces_comp-cui/2.0.1/cui/picker/picker.js": [
            "ces_comp-cui/2.0.1/cui/picker/picker-slot.js",
            "ces_comp-cui/2.0.1/cui/picker/picker.css"
        ],
        "ces_comp-cui/2.0.1/cui/popup/popup.js": [
            "ces_comp-cui/2.0.1/vue-popup/vue-popup.js",
            "ces_comp-cui/2.0.1/vue-event-bus/vue-event-bus.js",
            "ces_comp-cui/2.0.1/cui/popup/popup.css"
        ],
        "ces_comp-cui/2.0.1/cui/progress/progress.js": [
            "ces_comp-cui/2.0.1/cui/progress/progress.css"
        ],
        "ces_comp-cui/2.0.1/cui/radio/radio.js": [
            "ces_comp-cui/2.0.1/cui/cell/cell.js",
            "ces_comp-cui/2.0.1/cui/radio/radio.css"
        ],
        "ces_comp-cui/2.0.1/cui/range/range.js": [
            "ces_comp-cui/2.0.1/cui/range/draggable.js",
            "ces_comp-cui/2.0.1/cui/range/range.css"
        ],
        "ces_comp-cui/2.0.1/cui/search/search.js": [
            "ces_comp-cui/2.0.1/cui/cell/cell.js",
            "ces_comp-cui/2.0.1/cui/search/search.css"
        ],
        "ces_comp-cui/2.0.1/cui/spinner/spinner.js": [
            "ces_comp-cui/2.0.1/cui/spinner/spinner/snake.js",
            "ces_comp-cui/2.0.1/cui/spinner/spinner/double-bounce.js",
            "ces_comp-cui/2.0.1/cui/spinner/spinner/triple-bounce.js",
            "ces_comp-cui/2.0.1/cui/spinner/spinner/fading-circle.js",
            "ces_comp-cui/2.0.1/cui/spinner/spinner.css"
        ],
        "ces_comp-cui/2.0.1/cui/spinner/spinner/double-bounce.js": [
            "ces_comp-cui/2.0.1/cui/spinner/spinner/common.js"
        ],
        "ces_comp-cui/2.0.1/cui/spinner/spinner/fading-circle.js": [
            "ces_comp-cui/2.0.1/cui/spinner/spinner/common.js"
        ],
        "ces_comp-cui/2.0.1/cui/spinner/spinner/snake.js": [
            "ces_comp-cui/2.0.1/cui/spinner/spinner/common.js"
        ],
        "ces_comp-cui/2.0.1/cui/spinner/spinner/triple-bounce.js": [
            "ces_comp-cui/2.0.1/cui/spinner/spinner/common.js"
        ],
        "ces_comp-cui/2.0.1/cui/swipe/swipe.js": [
            "ces_comp-cui/2.0.1/wind-dom/event.js",
            "ces_comp-cui/2.0.1/wind-dom/class.js",
            "ces_comp-cui/2.0.1/cui/swipe/swipe.css"
        ],
        "ces_comp-cui/2.0.1/cui/switch/switch.js": [
            "ces_comp-cui/2.0.1/cui/switch/switch.css"
        ],
        "ces_comp-cui/2.0.1/cui/tab-container-item/tab-container-item.js": [
            "ces_comp-cui/2.0.1/cui/tab-container-item/tab-container-item.css"
        ],
        "ces_comp-cui/2.0.1/cui/tab-container/tab-container.js": [
            "ces_comp-cui/2.0.1/wind-dom/event.js",
            "ces_comp-cui/2.0.1/array-find-index/index.js",
            "ces_comp-cui/2.0.1/cui/tab-container/tab-container.css"
        ],
        "ces_comp-cui/2.0.1/cui/tab-item/tab-item.js": [
            "ces_comp-cui/2.0.1/cui/tab-item/tab-item.css"
        ],
        "ces_comp-cui/2.0.1/cui/tabbar/tabbar.js": [
            "ces_comp-cui/2.0.1/cui/tabbar/tabbar.css"
        ],
        "ces_comp-cui/2.0.1/cui/toast/toast.js": [
            "vue",
            "ces_comp-cui/2.0.1/cui/toast/toast.css"
        ],
        "ces_comp-cui/2.0.1/vue-event-bus/vue-event-bus.js": [
            "vue"
        ],
        "ces_comp-cui/2.0.1/vue-lazyload/vue-lazyload.js": [
            "es6-promise"
        ],
        "ces_comp-cui/2.0.1/vue-popup/vue-popup.js": [
            "vue",
            "ces_comp-cui/2.0.1/vue-popup/util.js",
            "ces_comp-cui/2.0.1/vue-popup/popup-manager.js",
            "ces_comp-cui/2.0.1/vue-event-bus/vue-event-bus.js",
            "ces_comp-cui/2.0.1/vue-popup/vue-popup.css"
        ],
        "ces_comp-cui/2.0.1/wind-dom/index.js": [
            "ces_comp-cui/2.0.1/wind-dom/class.js",
            "ces_comp-cui/2.0.1/wind-dom/event.js",
            "ces_comp-cui/2.0.1/wind-dom/style.js",
            "ces_comp-cui/2.0.1/wind-dom/create.js"
        ],
        "ces_comp-vuerify/0.4.0/vuerify.js": [
            "simple-assign"
        ],
        "jxapp/1.0.0/api/api.js": [
            "jxapp/1.0.0/api/storage.js",
            "cui",
            "ces",
            "ces-vue-resource",
            "vue",
            "es6-promise"
        ],
        "jxapp/1.0.0/attachment/index.js": [
            "ces",
            "cui",
            "jxapp/1.0.0/attachment/ajax.js"
        ],
        "jxapp/1.0.0/bespeakList/index.js": [
            "moment",
            "jxapp/1.0.0/bespeakList/index.css"
        ],
        "jxapp/1.0.0/comboDetail/index.js": [
            "ces",
            "cui",
            "api",
            "moment",
            "jxapp/1.0.0/api/storage.js",
            "jxapp/1.0.0/comboDetail/index.css"
        ],
        "jxapp/1.0.0/examCollect/examCollect.js": [
            "ces",
            "cui"
        ],
        "jxapp/1.0.0/examRules/examRules.js": [
            "ces",
            "cui",
            "api",
            "moment",
            "jxapp/1.0.0/examRules/examRules.css"
        ],
        "jxapp/1.0.0/examStorage/examStorage.js": [
            "ces",
            "cui"
        ],
        "jxapp/1.0.0/exams/exams.js": [
            "ces",
            "cui",
            "examCollect",
            "examStorage",
            "jxapp/1.0.0/exams/exams.css"
        ],
        "jxapp/1.0.0/examsDir/examsDir.js": [
            "ces",
            "cui",
            "api",
            "jxapp/1.0.0/examsDir/examsDir.css"
        ],
        "jxapp/1.0.0/examsLocal/examsLocal.js": [
            "ces",
            "cui",
            "examCollect",
            "jxapp/1.0.0/examsLocal/examsLocal.css"
        ],
        "jxapp/1.0.0/exercise/index.js": [
            "ces",
            "cui",
            "examCollect",
            "jxapp/1.0.0/exercise/index.css"
        ],
        "jxapp/1.0.0/forgotPassword/index.js": [
            "ces",
            "cui",
            "api"
        ],
        "jxapp/1.0.0/helper/helper.js": [
            "ces",
            "cui"
        ],
        "jxapp/1.0.0/index/index.js": [
            "ces",
            "cui",
            "api",
            "helper",
            "jxapp/1.0.0/api/storage.js",
            "jxapp/1.0.0/index/index.css"
        ],
        "jxapp/1.0.0/login/index.js": [
            "ces",
            "cui",
            "jxapp/1.0.0/login/index.css"
        ],
        "jxapp/1.0.0/notice/notice.js": [
            "ces",
            "cui",
            "api"
        ],
        "jxapp/1.0.0/personal/index.js": [
            "cui",
            "ces",
            "plugins",
            "vue",
            "jxapp/1.0.0/attachment/index.js",
            "jxapp/1.0.0/personal/index.css"
        ],
        "jxapp/1.0.0/plugins/plugins.js": [
            "ces",
            "cui"
        ],
        "jxapp/1.0.0/problem/problem.js": [
            "ces",
            "cui",
            "api"
        ],
        "jxapp/1.0.0/process/process.js": [
            "ces",
            "cui",
            "api"
        ],
        "jxapp/1.0.0/promise/promise.js": [
            "ces",
            "cui",
            "api",
            "jxapp/1.0.0/promise/promise.css"
        ],
        "jxapp/1.0.0/register/index.js": [
            "ces",
            "cui",
            "jxapp/1.0.0/register/index.css"
        ],
        "jxapp/1.0.0/reserved/index.js": [
            "ces",
            "cui",
            "api",
            "moment",
            "helper",
            "jxapp/1.0.0/reserved/index.css"
        ],
        "jxapp/1.0.0/routes/routes.js": [
            "vue",
            "jxapp/1.0.0/vee-validate/index.js",
            "index",
            "jxapp/1.0.0/exercise/index.js",
            "jxapp/1.0.0/reserved/index.js",
            "jxapp/1.0.0/personal/index.js",
            "exams",
            "examsDir",
            "examsLocal",
            "jxapp/1.0.0/login/index.js",
            "jxapp/1.0.0/register/index.js",
            "jxapp/1.0.0/forgotPassword/index.js",
            "success",
            "jxapp/1.0.0/comboDetail/index.js",
            "jxapp/1.0.0/bespeakList/index.js",
            "jxapp/1.0.0/shuttleList/index.js",
            "promise",
            "notice",
            "problem",
            "process",
            "examRules"
        ],
        "jxapp/1.0.0/shuttleList/index.js": [
            "jxapp/1.0.0/shuttleList/index.css"
        ],
        "jxapp/1.0.0/success/success.js": [
            "ces",
            "cui",
            "api",
            "jxapp/1.0.0/success/success.css"
        ],
        "jxapp/1.0.0/vee-validate/index.js": [
            "cui",
            "vue",
            "jxapp/1.0.0/vee-validate/locale/zh_CN.js",
            "vee-validate"
        ],
        "jxapp/1.0.0/vue-touch/vue-touch.js": [
            "jxapp/1.0.0/vue-touch/hammer.js"
        ],
        "jxapp/1.0.0/vue-touch/vue-touch.min.js": [
            "jxapp/1.0.0/vue-touch/hammer.js"
        ]
    },
    "config": {
        "pkg": "com.hxueche",
        "px2rem": true,
        "plugin": true,
        "debug": true,
        "service": "http",
        "ServiceEncrypt": true,
        "Server": {
            "defaultProtocol": "https",
            "serverIp": "www.hxueche.cn",
            "serverPort": "",
            "serverContext": "",
            "timeOut": 10000
        },
        "test": "/jxapp/1.0.0/index/index.html",
        "index": "/index/index.html"
    }
});

require.async(['ces',
    'vue',
    'cui',
    'api',
    'vue-router',
    'routes',
    'vue-touch'
], function (Ces,
             Vue,
             Cui,
             Api,
             VueRouter,
             Routes,
             VueTouch) {

    VueTouch.install(Vue);
    Vue.use(Api);

    var _app = {
        init: function (account, role) {
            Vue.use(VueRouter);

            var d = {
                wrapperHeight: '',
                backable: false,
                searchable: false,
                showLogo: true,
                title: '预约学车',
                value: '',
                animate: "left-fade",
                searchText: '',
                fullScreen: false,
                showToolBar: false
            };

            var router = new VueRouter({
                routes: Routes.routes
            });

            router.beforeEach(function (to, from, next) {
                if (to.path === '/') {
                    d.showToolBar = true;
                    next('/index');
                } else {
                    if (app) {
                        app.fullScreen = to.meta.fullScreen;
                        app.showToolBar = to.meta.showToolBar;
                        //app.title = to.meta.title;
                        app.backable = to.meta.backable;
                        app.searchable = to.meta.searchable;
                        //app.showLogo = to.meta.showLogo;
                        if (to.meta.value === from.meta.value) {
                            app.animate = "fade";
                        } else if (to.meta.value > from.meta.value) {
                            app.animate = "left-fade";
                        } else {
                            app.animate = "right-fade";
                        }
                    }
                    next();
                }

            });

            var app = new Vue({
                el: '#app',
                router: router,
                mounted: function () {
                    if (!this.showToolBar &&
                        (
                            window.location.hash.indexOf('index') > -1 ||
                            window.location.hash.indexOf('exercise') > -1 ||
                            window.location.hash.indexOf('reserved') > -1 ||
                            window.location.hash.indexOf('personal') > -1
                        )) {
                        this.showToolBar = true;
                    }

                    if (window.location.hash.indexOf('login') > -1) {
                        this.fullScreen = false;
                    }
                },
                data: function () {
                    return d;
                },
                methods: {
                    back: function () {
                        this.$router.back();
                    }
                },
                updated: function () {
                    this.wrapperHeight = document.documentElement.clientHeight
                        - this.$refs.title.clientHeight
                        - this.$refs.toolbar.clientHeight;
                }
            }).$mount('#app');
        }
    };

    Ces.ready(function () {
        _app.init()
    });
    // _app.init()
});

